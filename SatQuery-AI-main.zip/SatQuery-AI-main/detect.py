"""Water / flood-extent detection from NASA OPERA DSWx-HLS (30 m surface water extent).

Change detection, not a guess: classify water on an EVENT date and a BASELINE date,
compare only pixels that are valid (non-cloud) in BOTH, and grid the difference.

  new_water       - water on the event date, land on the baseline date  -> excess inundation
  permanent_water - water on both dates                                 -> river channel

When Bhoonidhi SAR lands, swap water_mask() for a backscatter threshold; everything
downstream (gridding, hectares, DB, map) is unchanged - and it then works through cloud.
"""
import argparse, io, math
import httpx
import numpy as np
from PIL import Image
import db

GIBS = "https://gibs.earthdata.nasa.gov/wms/epsg4326/best/wms.cgi"
DSWX = "OPERA_L3_Dynamic_Surface_Water_Extent-HLS"
SIZE = 1024

# DSWx-HLS rendered classes as served by GIBS
OPEN_WATER = [(0, 0, 255), (0, 255, 255)]
PARTIAL_WATER = [(180, 213, 244)]
NOT_WATER = [(255, 255, 255)]
NODATA = [(175, 175, 175)]          # cloud / cloud shadow / fill


def grab(bbox, date, layer=DSWX, size=SIZE):
    lon0, lat0, lon1, lat1 = bbox
    r = httpx.get(GIBS, params={
        "SERVICE": "WMS", "REQUEST": "GetMap", "VERSION": "1.3.0", "LAYERS": layer,
        "CRS": "EPSG:4326", "BBOX": f"{lat0},{lon0},{lat1},{lon1}",
        "WIDTH": size, "HEIGHT": size, "FORMAT": "image/png",
        "TRANSPARENT": "true", "TIME": date}, timeout=120)
    r.raise_for_status()
    if "png" not in r.headers.get("content-type", ""):
        raise RuntimeError(f"GIBS refused: {r.text[:200]}")
    return np.array(Image.open(io.BytesIO(r.content)).convert("RGBA"))


def _match(rgb, palette):
    return np.any([np.all(rgb == c, axis=-1) for c in palette], axis=0)


def water_mask(arr):
    """-> (water, valid). valid excludes cloud/nodata/transparent so we never
    mistake 'could not see' for 'no water'."""
    rgb, alpha = arr[:, :, :3], arr[:, :, 3]
    seen = alpha > 0
    valid = seen & ~_match(rgb, NODATA)
    water = valid & (_match(rgb, OPEN_WATER) | _match(rgb, PARTIAL_WATER))
    return water, valid


def cell_hectares(bbox, nx, ny):
    lon0, lat0, lon1, lat1 = bbox
    lat_mid = math.radians((lat0 + lat1) / 2)
    m_lat = 110574.0 * (lat1 - lat0) / ny
    m_lon = 111320.0 * math.cos(lat_mid) * (lon1 - lon0) / nx
    return abs(m_lat * m_lon) / 10_000.0


def gridify(bbox, event, baseline, cells_across=64, thresh=0.4):
    """Downsample per-pixel masks to map cells. A cell counts only if most of it was
    observable on both dates (thresh), so partial swaths do not invent findings."""
    ew, ev = water_mask(event)
    bw, bv = water_mask(baseline)
    both = ev & bv
    ny = max(1, round(cells_across * (bbox[3] - bbox[1]) / (bbox[2] - bbox[0])))
    nx = cells_across
    h, w = ew.shape
    sy, sx = h // ny, w // nx
    ha = cell_hectares(bbox, nx, ny)
    lon0, lat0, lon1, lat1 = bbox
    out, observed = [], 0
    for j in range(ny):
        for i in range(nx):
            sl = (slice(j * sy, (j + 1) * sy), slice(i * sx, (i + 1) * sx))
            valid = both[sl]
            if valid.mean() < thresh:
                continue
            observed += 1
            e, b = ew[sl][valid].mean(), bw[sl][valid].mean()
            kind = ("permanent_water" if e >= thresh and b >= thresh else
                    "new_water" if e >= thresh else None)
            if not kind:
                continue
            # cell bbox; image row 0 is the NORTH edge
            out.append((kind,
                        lon0 + i * (lon1 - lon0) / nx, lat1 - (j + 1) * (lat1 - lat0) / ny,
                        lon0 + (i + 1) * (lon1 - lon0) / nx, lat1 - j * (lat1 - lat0) / ny,
                        round(ha, 2)))
    return out, observed, nx * ny


def run(aoi, bbox, event_date, baseline_date, cells_across=64):
    ev = grab(bbox, event_date)
    bl = grab(bbox, baseline_date)
    cells, observed, total = gridify(bbox, ev, bl, cells_across)
    tile_id = f"{aoi.lower().replace(' ', '_')}_{event_date}"
    db.replace_detections(tile_id, f"{aoi.lower().replace(' ', '_')}_{baseline_date}", cells)
    db.set_observed(tile_id, observed, total)
    s = db.summary(tile_id)
    print(f"{tile_id}: observed {observed}/{total} cells "
          f"({observed / total:.0%} co-visible on both dates)")
    for k, v in sorted(s.items()):
        print(f"  {k:16} {v['cells']:>4} cells  {v['hectares']:>9,.0f} ha")
    return s


def demo():
    """Self-check: synthetic masks with a known answer, no network."""
    bbox = (93.0, 26.0, 94.0, 27.0)
    n = 64
    ev = np.zeros((n, n, 4), np.uint8); ev[:, :, 3] = 255
    bl = ev.copy()
    ev[:, :] = [255, 255, 255, 255]; bl[:, :] = [255, 255, 255, 255]   # all land
    ev[0:32, :] = [0, 0, 255, 255]                                     # top half water on event
    bl[0:16, :] = [0, 0, 255, 255]                                     # top quarter water on baseline
    bl[48:, :] = [175, 175, 175, 255]                                  # bottom quarter cloudy on baseline
    cells, observed, total = gridify(bbox, ev, bl, cells_across=4)
    kinds = {}
    for k, *_ , ha in cells:
        kinds[k] = kinds.get(k, 0) + 1
    assert observed == 12, observed                    # bottom row unobservable -> excluded
    assert kinds.get("permanent_water") == 4, kinds    # top row: water both dates
    assert kinds.get("new_water") == 4, kinds          # second row: water only on event date
    assert abs(cell_hectares(bbox, 4, 4) - 68_800) < 2_000, cell_hectares(bbox, 4, 4)
    print("detect.demo ok")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--aoi"); p.add_argument("--bbox", nargs=4, type=float)
    p.add_argument("--event"); p.add_argument("--baseline")
    p.add_argument("--cells", type=int, default=64)
    p.add_argument("--demo", action="store_true")
    a = p.parse_args()
    if a.demo or not a.aoi:
        demo()
    else:
        run(a.aoi, a.bbox, a.event, a.baseline, a.cells)


def clusters(cells, kind="new_water", cell_deg=None):
    """Group adjacent detection cells into contiguous affected areas.
    cells: rows from db.detections(). Returns largest-first with centroid + hectares."""
    sel = [c for c in cells if c["kind"] == kind]
    if not sel:
        return []
    w = cell_deg or min(c["lon1"] - c["lon0"] for c in sel)
    h = cell_deg or min(c["lat1"] - c["lat0"] for c in sel)
    grid = {(round(c["lon0"] / w), round(c["lat0"] / h)): c for c in sel}
    seen, out = set(), []
    for key in grid:
        if key in seen:
            continue
        stack, group = [key], []
        seen.add(key)
        while stack:
            i, j = stack.pop()
            group.append(grid[(i, j)])
            for nb in ((i+1, j), (i-1, j), (i, j+1), (i, j-1)):
                if nb in grid and nb not in seen:
                    seen.add(nb); stack.append(nb)
        ha = sum(c["hectares"] for c in group)
        out.append({"cells": len(group), "hectares": round(ha, 1),
                    "lat": round(sum((c["lat0"] + c["lat1"]) / 2 for c in group) / len(group), 4),
                    "lon": round(sum((c["lon0"] + c["lon1"]) / 2 for c in group) / len(group), 4),
                    "bbox": [min(c["lon0"] for c in group), min(c["lat0"] for c in group),
                             max(c["lon1"] for c in group), max(c["lat1"] for c in group)]})
    return sorted(out, key=lambda g: -g["hectares"])
