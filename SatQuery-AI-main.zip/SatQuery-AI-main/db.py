"""SQLite store for SatQuery AI.

Three tables:
  tiles       - one row per downloaded, georeferenced image tile
  detections  - water/flood cells derived from those tiles (the map overlay)
  queries     - every question asked, with the answer and latency (audit trail + demo analytics)

sqlite3 is in the Python standard library, so there is no server to install or run.
"""
import json, pathlib, sqlite3, time
from contextlib import contextmanager

DB = pathlib.Path(__file__).parent / "data" / "satquery.db"

SCHEMA = """
CREATE TABLE IF NOT EXISTS tiles (
  id TEXT PRIMARY KEY, aoi TEXT NOT NULL, date TEXT NOT NULL,
  lon0 REAL, lat0 REAL, lon1 REAL, lat1 REAL,
  cloud REAL, coverage REAL, source TEXT, sensor TEXT,
  cells_observed INTEGER, cells_total INTEGER,
  optical_path TEXT, sar_path TEXT, note TEXT
);
CREATE TABLE IF NOT EXISTS detections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tile_id TEXT NOT NULL REFERENCES tiles(id) ON DELETE CASCADE,
  baseline_tile_id TEXT, kind TEXT NOT NULL,          -- 'new_water' | 'permanent_water'
  lon0 REAL, lat0 REAL, lon1 REAL, lat1 REAL, hectares REAL
);
CREATE INDEX IF NOT EXISTS det_tile ON detections(tile_id, kind);
CREATE TABLE IF NOT EXISTS queries (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, question TEXT NOT NULL,
  place TEXT, tile_id TEXT, answer TEXT, regions_json TEXT, ms INTEGER, ok INTEGER
);
"""


@contextmanager
def conn():
    """Commit on clean exit, always close - sqlite3's own context manager commits but
    leaves the handle open, which leaks file descriptors in a long-running server."""
    DB.parent.mkdir(parents=True, exist_ok=True)
    c = sqlite3.connect(DB)
    try:
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA foreign_keys=ON")
        c.executescript(SCHEMA)
        yield c
        c.commit()
    finally:
        c.close()


def upsert_tile(t):
    with conn() as c:
        c.execute("""INSERT INTO tiles
            (id,aoi,date,lon0,lat0,lon1,lat1,cloud,coverage,source,sensor,optical_path,sar_path,note)
            VALUES (:id,:aoi,:date,:lon0,:lat0,:lon1,:lat1,:cloud,:coverage,:source,:sensor,
                    :optical_path,:sar_path,:note)
            ON CONFLICT(id) DO UPDATE SET
              date=excluded.date, cloud=excluded.cloud, coverage=excluded.coverage,
              source=excluded.source, sensor=excluded.sensor, optical_path=excluded.optical_path,
              sar_path=excluded.sar_path, note=excluded.note""", t)


def replace_detections(tile_id, baseline_id, cells):
    """cells: [(kind, lon0, lat0, lon1, lat1, hectares), ...]"""
    with conn() as c:
        c.execute("DELETE FROM detections WHERE tile_id=?", (tile_id,))
        c.executemany("""INSERT INTO detections
            (tile_id,baseline_tile_id,kind,lon0,lat0,lon1,lat1,hectares)
            VALUES (?,?,?,?,?,?,?,?)""",
            [(tile_id, baseline_id, *cell) for cell in cells])


def set_observed(tile_id, observed, total):
    with conn() as c:
        c.execute("UPDATE tiles SET cells_observed=?, cells_total=? WHERE id=?",
                  (observed, total, tile_id))


def tiles(aoi=None):
    q = "SELECT * FROM tiles" + (" WHERE aoi=?" if aoi else "") + " ORDER BY date DESC"
    with conn() as c:
        return [dict(r) for r in c.execute(q, (aoi,) if aoi else ())]


def tile(tile_id):
    with conn() as c:
        r = c.execute("SELECT * FROM tiles WHERE id=?", (tile_id,)).fetchone()
        return dict(r) if r else None


def detections(tile_id):
    with conn() as c:
        return [dict(r) for r in c.execute(
            "SELECT kind,lon0,lat0,lon1,lat1,hectares FROM detections WHERE tile_id=?", (tile_id,))]


def summary(tile_id):
    """Hectares per class - this is where the '340 hectares' style number comes from."""
    with conn() as c:
        return {r["kind"]: {"cells": r["n"], "hectares": round(r["ha"], 1)} for r in c.execute(
            "SELECT kind, COUNT(*) n, SUM(hectares) ha FROM detections WHERE tile_id=? GROUP BY kind",
            (tile_id,))}


def log_query(question, place, tile_id, answer, regions, ms, ok):
    with conn() as c:
        c.execute("""INSERT INTO queries (ts,question,place,tile_id,answer,regions_json,ms,ok)
                     VALUES (?,?,?,?,?,?,?,?)""",
                  (time.time(), question, place, tile_id, answer,
                   json.dumps(regions or []), ms, int(ok)))


def recent_queries(n=20):
    with conn() as c:
        return [dict(r) for r in c.execute(
            "SELECT id,ts,question,place,tile_id,ms,ok FROM queries ORDER BY id DESC LIMIT ?", (n,))]


if __name__ == "__main__":
    with conn() as c:
        for t in ("tiles", "detections", "queries"):
            print(f"{t:12} {c.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]:>6} rows")
