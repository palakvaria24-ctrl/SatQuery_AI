"""Package data/ into a zip for handoff, with credentials excluded.

    python package_data.py

Produces satquery-data.zip next to the project. data/ is gitignored (it is downloaded,
not authored), so this is how the recipient gets a working dataset without re-running
fetch_tiles.py against NASA GIBS.

Credential files are excluded and the finished archive is re-opened and verified, because
data/.bhoonidhi_token.json holds a live ISRO access token once you have logged in.
"""
import pathlib, sys, zipfile

ROOT = pathlib.Path(__file__).parent
DATA = ROOT / "data"
OUT = ROOT / "satquery-data.zip"

# Never ship these, even if someone adds them to data/ later.
BLOCK_NAMES = {".bhoonidhi_token.json", ".env"}
BLOCK_SUFFIXES = {".pem", ".key"}

NOTE = """SatQuery AI - dataset
=====================

Unzip so that `data/` sits next to server.py in the project root:

    satquery-ai/
      server.py
      data/          <-- from this zip
      web/

Contents
  satquery.db   SQLite database: tiles, detections (map overlay), query log
  tiles/        Sentinel-2 true-colour PNGs (real) + SAR placeholders

Then:
    pip install -r requirements.txt
    export GROQ_API_KEY=...
    python -m uvicorn server:app --port 8077

To rebuild this data from scratch instead, run:
    python fetch_tiles.py --aoi Majuli --bbox 93.90 26.90 94.30 27.10 \\
                          --event 2024-10-19 --baseline 2024-11-28

No credentials are included in this archive.
"""


def blocked(p):
    return p.name in BLOCK_NAMES or p.suffix in BLOCK_SUFFIXES


def main():
    if not DATA.is_dir():
        sys.exit("No data/ directory. Run fetch_tiles.py first.")

    files = sorted(p for p in DATA.rglob("*") if p.is_file())
    keep = [p for p in files if not blocked(p)]
    skipped = [p for p in files if blocked(p)]
    if not keep:
        sys.exit("data/ has nothing to package.")

    with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in keep:
            z.write(p, p.relative_to(ROOT).as_posix())
        z.writestr("data/READ-ME-FIRST.txt", NOTE)

    # Verify what actually landed in the archive rather than trusting the loop above.
    with zipfile.ZipFile(OUT) as z:
        names = z.namelist()
        bad = [n for n in names
               if pathlib.PurePosixPath(n).name in BLOCK_NAMES
               or pathlib.PurePosixPath(n).suffix in BLOCK_SUFFIXES]
        if bad:
            OUT.unlink()
            sys.exit(f"Refusing to ship: credential files found in archive: {bad}")
        assert z.testzip() is None, "archive is corrupt"

    print(f"{OUT.name}  ({OUT.stat().st_size / 1e6:.1f} MB, {len(names)} entries)")
    for n in names:
        print(f"    {n}")
    for p in skipped:
        print(f"  excluded (credential): {p.name}")
    print("\nVerified: no credential files in the archive.")


if __name__ == "__main__":
    main()
