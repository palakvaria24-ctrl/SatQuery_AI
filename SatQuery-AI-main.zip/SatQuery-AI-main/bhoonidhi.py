"""ISRO Bhoonidhi (NRSC) data access client.

Implements the documented flow: /auth/token -> /data/search (STAC) -> /download.
Register a free account at https://bhoonidhi.nrsc.gov.in, then:

    export BHOONIDHI_USER=...  BHOONIDHI_PASS=...
    python bhoonidhi.py collections
    python bhoonidhi.py search --collection Sentinel-1A_SAR-IW_GRD \
        --bbox 93.90 26.90 94.30 27.10 --start 2024-10-01 --end 2024-10-31
    python bhoonidhi.py download --collection Sentinel-1A_SAR-IW_GRD \
        --bbox 93.90 26.90 94.30 27.10 --start 2024-10-01 --end 2024-10-31 --out data/sar

Why this matters: optical water detection fails under monsoon cloud - exactly when floods
peak. Sentinel-1 / EOS-04 SAR sees through cloud, so swapping detect.water_mask() to a SAR
backscatter threshold makes the same pipeline work during an actual flood event.
"""
import argparse, json, os, pathlib, time
import httpx
import config  # loads .env

BASE = "https://bhoonidhi-api.nrsc.gov.in"
TOKEN_CACHE = pathlib.Path(__file__).parent / "data" / ".bhoonidhi_token.json"

SAR_COLLECTIONS = ["Sentinel-1A_SAR-IW_GRD", "EOS-04_SAR-MRS_L2B",
                   "EOS-04_SAR-CRS_L2B", "EOS-04_SAR-FRS1_L2A"]


class Bhoonidhi:
    def __init__(self, user=None, password=None):
        self.user = user or os.environ.get("BHOONIDHI_USER")
        self.password = password or os.environ.get("BHOONIDHI_PASS")
        self.http = httpx.Client(timeout=120, follow_redirects=True)
        self._tok = None

    # ---- auth -------------------------------------------------------------
    def _load_cached(self):
        if not TOKEN_CACHE.exists():
            return None
        try:
            t = json.loads(TOKEN_CACHE.read_text())
        except json.JSONDecodeError:
            return None
        return t if t.get("expires_at", 0) - 60 > time.time() else t  # keep for refresh

    def _save(self, t):
        TOKEN_CACHE.parent.mkdir(parents=True, exist_ok=True)
        TOKEN_CACHE.write_text(json.dumps(t))
        try:
            os.chmod(TOKEN_CACHE, 0o600)
        except OSError:
            pass                                   # best effort; Windows ACLs differ

    def token(self):
        """Cached access token. Tokens last ~20 min - the docs explicitly ask clients not
        to fetch a new one per request, and token retrieval is itself rate limited."""
        if self._tok and self._tok["expires_at"] - 60 > time.time():
            return self._tok["access_token"]
        cached = self._load_cached()
        if cached and cached["expires_at"] - 60 > time.time():
            self._tok = cached
            return cached["access_token"]
        if cached and cached.get("refresh_token"):
            try:
                self._tok = self._auth({"userId": cached["userId"],
                                        "refresh_token": cached["refresh_token"],
                                        "grant_type": "refresh_token"})
                return self._tok["access_token"]
            except httpx.HTTPStatusError:
                pass                               # refresh expired -> full login
        if not (self.user and self.password):
            raise SystemExit("Set BHOONIDHI_USER and BHOONIDHI_PASS "
                             "(free account at https://bhoonidhi.nrsc.gov.in).")
        self._tok = self._auth({"userId": self.user, "password": self.password,
                                "grant_type": "password"})
        return self._tok["access_token"]

    def _auth(self, payload):
        r = self.http.post(f"{BASE}/auth/token", json=payload)
        if r.status_code == 401:
            raise SystemExit("Bhoonidhi rejected the credentials (401).")
        if r.status_code == 403:
            raise SystemExit("Bhoonidhi: max sessions active (403). Log out elsewhere first.")
        if r.status_code == 429:
            raise SystemExit("Bhoonidhi: too many token requests (429). Wait, then retry.")
        r.raise_for_status()
        t = r.json()
        t["expires_at"] = time.time() + int(t.get("expires_in", 1200))
        t.setdefault("userId", payload["userId"])
        self._save(t)
        return t

    def _headers(self):
        return {"Authorization": f"Bearer {self.token()}"}

    # ---- catalogue --------------------------------------------------------
    def collections(self):
        r = self.http.get(f"{BASE}/data/collections", headers=self._headers())
        r.raise_for_status()
        return r.json()

    def search(self, collection, bbox, start, end, limit=20, online_only=True):
        """STAC item-search. `online_only` keeps products available for direct download
        rather than ones needing staging from tape."""
        body = {"collections": [collection],
                "bbox": [str(v) for v in bbox],
                "datetime": f"{start}T00:00:00Z/{end}T23:59:59Z",
                "limit": limit}
        if online_only:
            body["filter-lang"] = "cql2-json"
            body["filter"] = {"op": "eq", "args": [{"property": "Online"}, "Y"]}
        r = self.http.post(f"{BASE}/data/search", json=body, headers=self._headers())
        if r.status_code == 401:
            self._tok = None
            TOKEN_CACHE.unlink(missing_ok=True)
            raise SystemExit("Bhoonidhi session expired. Re-run to log in again.")
        r.raise_for_status()
        return r.json()

    def download(self, item, out_dir):
        """Fetch the first downloadable asset of a STAC item."""
        out_dir = pathlib.Path(out_dir)
        out_dir.mkdir(parents=True, exist_ok=True)
        assets = item.get("assets") or {}
        href = next((a["href"] for a in assets.values() if a.get("href")), None)
        if not href:
            href = next((l["href"] for l in item.get("links", [])
                         if l.get("rel") in ("download", "data")), None)
        if not href:
            raise RuntimeError(f"No downloadable asset on item {item.get('id')}")
        if href.startswith("/"):
            href = BASE + href
        dest = out_dir / f"{item['id']}.zip"
        with self.http.stream("GET", href, headers=self._headers()) as r:
            r.raise_for_status()
            with open(dest, "wb") as f:
                for chunk in r.iter_bytes(1 << 20):
                    f.write(chunk)
        return dest


def main():
    p = argparse.ArgumentParser(description="ISRO Bhoonidhi client")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("collections")
    for name in ("search", "download"):
        s = sub.add_parser(name)
        s.add_argument("--collection", default="Sentinel-1A_SAR-IW_GRD")
        s.add_argument("--bbox", nargs=4, type=float, required=True)
        s.add_argument("--start", required=True)
        s.add_argument("--end", required=True)
        s.add_argument("--limit", type=int, default=20)
        if name == "download":
            s.add_argument("--out", default="data/sar")
            s.add_argument("--max", type=int, default=1)
    a = p.parse_args()
    b = Bhoonidhi()

    if a.cmd == "collections":
        cols = b.collections()
        ids = [c.get("id", c) for c in (cols.get("collections") or cols)]
        print(f"{len(ids)} collections; SAR ones:")
        for i in ids:
            if "SAR" in str(i) or "NISAR" in str(i):
                print("  ", i)
        return

    res = b.search(a.collection, a.bbox, a.start, a.end, a.limit)
    feats = res.get("features", [])
    print(f"{len(feats)} item(s) in {a.collection} for {a.start}..{a.end}")
    for f in feats:
        print(f"  {f['id']}  {f.get('properties', {}).get('datetime', '?')}")
    if a.cmd == "download":
        for f in feats[:a.max]:
            print("downloading", f["id"])
            print("  ->", b.download(f, a.out))


if __name__ == "__main__":
    main()
