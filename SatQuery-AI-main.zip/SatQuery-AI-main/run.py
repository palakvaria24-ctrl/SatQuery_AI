"""One command to check everything and start SatQuery AI.

    python run.py                 check, then serve on http://localhost:8077
    python run.py --check         check only, do not start the server
    python run.py --port 8000     serve on a different port

Checks Python, dependencies, the API key, sample data and the test suite. If no key is
found it asks for one and writes it to .env, which is gitignored - so a key pasted here
never reaches a commit.
"""
import argparse, getpass, importlib, pathlib, shutil, subprocess, sys, webbrowser

ROOT = pathlib.Path(__file__).parent
ENV = ROOT / ".env"
DEPS = {"fastapi": "fastapi", "uvicorn": "uvicorn", "httpx": "httpx",
        "PIL": "pillow", "numpy": "numpy", "scipy": "scipy", "rasterio": "rasterio"}

OK, WARN, BAD = "[ ok ]", "[warn]", "[FAIL]"
_fails = []


def say(status, msg, detail=""):
    print(f" {status} {msg}" + (f"\n        {detail}" if detail else ""))
    if status == BAD:
        _fails.append(msg)


def check_python():
    v = sys.version_info
    if v < (3, 9):
        say(BAD, f"Python {v.major}.{v.minor}", "Python 3.9 or newer is required.")
    else:
        say(OK, f"Python {v.major}.{v.minor}.{v.micro}")


def check_deps(auto_install=True):
    missing = [pkg for mod, pkg in DEPS.items() if not _has(mod)]
    if not missing:
        say(OK, f"dependencies ({len(DEPS)} packages)")
        return
    say(WARN, f"missing: {', '.join(missing)}")
    if not auto_install:
        say(BAD, "dependencies", "run: pip install -r requirements.txt")
        return
    print(f"        installing {len(missing)} package(s)...")
    r = subprocess.run([sys.executable, "-m", "pip", "install", "-q", *missing])
    still = [p for m, p in DEPS.items() if not _has(m)]
    if r.returncode or still:
        say(BAD, "dependency install failed", "run: pip install -r requirements.txt")
    else:
        say(OK, "dependencies installed")


def _has(mod):
    try:
        importlib.import_module(mod)
        return True
    except Exception:
        return False


def check_key(interactive=True):
    """Environment -> .env -> ask. A pasted key is written to .env, never to source."""
    import config
    config.load_env()
    key = _current_key()
    if key:
        src = "environment" if _from_env() else ".env"
        say(OK, f"GROQ_API_KEY found ({src}, {_mask(key)})")
    else:
        if not interactive or not sys.stdin.isatty():
            say(BAD, "GROQ_API_KEY not set",
                "add a line  GROQ_API_KEY=your_key  to .env, or export it.")
            return
        print("\n  No Groq API key found. Get a free one at https://console.groq.com")
        print("  Paste it here (input hidden), or press Enter to skip:")
        try:
            key = getpass.getpass("  key> ").strip()
        except (EOFError, KeyboardInterrupt):
            key = ""
        if not key:
            say(BAD, "GROQ_API_KEY not set", "the map and measurements work; chat will not.")
            return
        _write_env(key)
        import os
        os.environ["GROQ_API_KEY"] = key
        say(OK, f"key saved to .env ({_mask(key)})", ".env is gitignored - it stays local.")
    _verify_key()


def _current_key():
    import os
    import config
    return os.environ.get("GROQ_API_KEY") or config.DEFAULTS.get("GROQ_API_KEY") or ""


def _from_env():
    import os
    return bool(os.environ.get("GROQ_API_KEY"))


def _mask(k):
    return f"{k[:6]}...{k[-4:]}" if len(k) > 12 else "set"


def _write_env(key):
    lines = []
    if ENV.exists():
        lines = [l for l in ENV.read_text(encoding="utf-8").splitlines()
                 if not l.strip().startswith("GROQ_API_KEY")]
    lines.append(f"GROQ_API_KEY={key}")
    ENV.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _verify_key():
    key = _current_key()
    if not key:
        return
    try:
        import httpx
        r = httpx.get("https://api.groq.com/openai/v1/models",
                      headers={"Authorization": f"Bearer {key}"}, timeout=20)
        if r.status_code == 200:
            say(OK, "key verified against the Groq API")
        elif r.status_code == 401:
            say(BAD, "the key was rejected (401)", "check it at https://console.groq.com")
        else:
            say(WARN, f"could not verify the key (HTTP {r.status_code})")
    except Exception as e:
        say(WARN, "could not reach Groq", f"{type(e).__name__} - offline? the app still starts.")


def check_data():
    tiles = sorted((ROOT / "data" / "tiles").glob("*.png"))
    (ROOT / "data" / "tiles").mkdir(parents=True, exist_ok=True)
    (ROOT / "data" / "uploads").mkdir(parents=True, exist_ok=True)
    if tiles:
        say(OK, f"sample imagery ({len(tiles)} tiles)")
    else:
        say(WARN, "no sample tiles",
            "upload your own, or use the Live satellite box in the app - both work.")
    free = shutil.disk_usage(ROOT).free / 1e9
    say(OK if free > 0.5 else WARN, f"disk free: {free:.1f} GB")


def check_tests():
    r = subprocess.run([sys.executable, "test_satquery.py"], cwd=ROOT,
                       capture_output=True, text=True)
    tail = (r.stdout or r.stderr).strip().splitlines()
    line = tail[-1] if tail else "no output"
    say(OK if r.returncode == 0 else BAD, f"tests: {line}")


def main():
    ap = argparse.ArgumentParser(description="Check the environment and start SatQuery AI")
    ap.add_argument("--check", action="store_true", help="run checks only")
    ap.add_argument("--port", type=int, default=8077)
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--skip-tests", action="store_true")
    a = ap.parse_args()

    print("\n  SatQuery AI - preflight\n  " + "-" * 46)
    check_python()
    check_deps()
    check_key()
    check_data()
    if not a.skip_tests:
        check_tests()
    print("  " + "-" * 46)

    if _fails:
        print(f"  {len(_fails)} problem(s): " + "; ".join(_fails))
        if any("Python" in f or "dependenc" in f for f in _fails):
            sys.exit(1)                      # cannot run at all
        print("  Starting anyway - the parts that do not need a key still work.\n")
    else:
        print("  All checks passed.\n")

    if a.check:
        return
    url = f"http://localhost:{a.port}"
    print(f"  Serving {url}   (Ctrl+C to stop)\n")
    if not a.no_browser:
        try:
            webbrowser.open(url)
        except Exception:
            pass
    try:
        subprocess.run([sys.executable, "-m", "uvicorn", "server:app",
                        "--port", str(a.port)], cwd=ROOT)
    except KeyboardInterrupt:
        print("\n  stopped.")


if __name__ == "__main__":
    main()
