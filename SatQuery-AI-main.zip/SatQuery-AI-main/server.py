"""SatQuery AI - backend.

Question -> parse -> geocode -> tile retrieval (SQLite) -> measured water-extent stats
         -> vision LLM writes the narrative -> answer + map overlay + coordinates.

The NUMBERS are measured by detect.py from NASA OPERA DSWx-HLS and stored in SQLite.
The LLM never estimates area; it explains measurements and reads the imagery.
"""
import base64, datetime, io, json, os, pathlib, time
import httpx
from fastapi import FastAPI, UploadFile, File
from fastapi.responses import FileResponse, PlainTextResponse
from fastapi.staticfiles import StaticFiles
from PIL import Image
from pydantic import BaseModel
import agent, config, db, detect, fetch_tiles, tools

ROOT = pathlib.Path(__file__).parent
GROQ = "https://api.groq.com/openai/v1/chat/completions"
VLM = os.environ.get("SATQUERY_VLM", "qwen/qwen3.8-27b")
TXT = os.environ.get("SATQUERY_TXT", "openai/gpt-oss-20b")

app = FastAPI(title="SatQuery AI")


def groq(messages, model, json_mode=False):
    key = config.require("GROQ_API_KEY")
    body = {"model": model, "messages": messages, "temperature": 0.2}
    if json_mode:
        body["response_format"] = {"type": "json_object"}
    for attempt in range(3):
        r = httpx.post(GROQ, json=body, headers={"Authorization": f"Bearer {key}"}, timeout=120)
        if r.status_code == 429:                      # free tier: image calls are token-heavy
            if attempt < 2:
                time.sleep(min(float(r.headers.get("retry-after", 5)), 20))
                continue
            try:
                msg = r.json()["error"]["message"]
            except Exception:
                msg = ""
            if "per day" in msg or "TPD" in msg:
                raise RuntimeError("Groq free-tier DAILY token limit reached. "
                                   "It resets in under an hour; measurements and the map "
                                   "still work, only the written answer is paused.")
            raise RuntimeError("Groq rate limit reached - wait about a minute and ask again.")
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]


def geocode(place):
    r = httpx.get("https://nominatim.openstreetmap.org/search",
                  params={"q": place, "format": "json", "limit": 1, "countrycodes": "in"},
                  headers={"User-Agent": "SatQuery-AI/0.2"}, timeout=20)
    hits = r.json() if r.status_code == 200 else []
    return (float(hits[0]["lon"]), float(hits[0]["lat"])) if hits else None


def retrieve(question, place):
    """AOI-name match first, then geocoded point-in-bbox. Only event tiles that carry
    detections are answerable."""
    rows = [t for t in db.tiles() if db.detections(t["id"])]
    ql = question.lower()
    named = [t for t in rows if t["aoi"].lower() in ql]
    if named:
        return named, None
    pt = geocode(place) if place else None
    if not pt:
        return [], None
    inside = [t for t in rows
              if t["lon0"] <= pt[0] <= t["lon1"] and t["lat0"] <= pt[1] <= t["lat1"]]
    return inside, pt


VLM_PX = int(os.environ.get("SATQUERY_VLM_PX", 512))


def data_url(rel, px=None):
    """Downscale before base64. Two full-res 1024px tiles make a ~5 MB request, which Groq
    rejects intermittently with a 400; the model only needs enough detail to describe
    pattern and context, since every number comes from detect.py."""
    px = px or VLM_PX
    img = Image.open(ROOT / rel).convert("RGB")
    if max(img.size) > px:
        img.thumbnail((px, px), Image.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=82)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()


def analysis(tile_id):
    """Everything measured about one event tile - shared by query, analysis and report."""
    t = db.tile(tile_id)
    cells = db.detections(tile_id)
    with db.conn() as c:
        row = c.execute("SELECT baseline_tile_id FROM detections WHERE tile_id=? LIMIT 1",
                        (tile_id,)).fetchone()
    base_id = row["baseline_tile_id"] if row else None
    base = db.tile(base_id) if base_id else None
    obs, tot = t.get("cells_observed"), t.get("cells_total")
    return {"tile": t, "baseline_tile_id": base_id,
            "comparable_pct": round(100 * obs / tot) if obs and tot else None,
            "baseline_date": base["date"] if base else None,
            "summary": db.summary(tile_id), "cells": cells,
            "clusters": detect.clusters(cells),
            "centroid": {"lat": round((t["lat0"] + t["lat1"]) / 2, 4),
                         "lon": round((t["lon0"] + t["lon1"]) / 2, 4)}}


PARSE = ('Extract from a remote-sensing question. JSON only: '
         '{"place": "<Indian place name or null>", "task": "flood|crop|water|other"}')

VISION = """You are a remote-sensing analyst briefing an Indian district disaster-management
or agriculture officer.

You are given MEASURED statistics from a NASA OPERA DSWx-HLS surface-water change analysis,
plus two true-colour tiles of the same ground area (image 1 = event date, image 2 = baseline).

The measurements are authoritative - quote them, never re-estimate area from the images.
Use the imagery only to describe pattern and context (where the water sits, terrain, settlement).

Write 3-5 plain sentences aimed at a real decision (where to send boats, which parcels to
inspect). Lead with the headline number and the coordinate. Flag the observed-coverage caveat
when coverage is below 80 percent. Never invent village names or casualty figures.

Always name the event date explicitly. This is archived imagery for a specific date, so never
write "right now", "currently" or "today", even if the question is phrased that way.

JSON only:
{"answer": "...", "headline": "one sentence with the key number and coordinate"}"""


class Q(BaseModel):
    q: str


@app.post("/api/query")
def query(body: Q):
    t0 = time.time()
    question = body.q.strip()
    if not question:
        return {"error": "Empty question."}

    try:
        parsed = json.loads(groq([{"role": "system", "content": PARSE},
                                  {"role": "user", "content": question}], TXT, json_mode=True))
    except Exception as e:
        db.log_query(question, None, None, None, None, int((time.time() - t0) * 1000), False)
        return {"error": f"Could not parse the question ({e})."}

    place = parsed.get("place")
    tiles, pt = retrieve(question, place)
    if not tiles:
        areas = sorted({t["aoi"] for t in db.tiles() if db.detections(t["id"])})
        db.log_query(question, place, None, None, None, int((time.time() - t0) * 1000), False)
        return {"error": f"No analysed imagery covers {place or 'that area'}. "
                         f"Available: {', '.join(areas) or 'none - run fetch_tiles.py'}",
                "point": pt, "areas": areas}

    tile = tiles[0]
    payload = analysis(tile["id"])
    stats = payload["summary"]
    top = payload["clusters"][:5]

    facts = (f"Area: {tile['aoi']} | event date {tile['date']} | "
             f"baseline {payload['baseline_date']}\n"
             f"Measured NEW water (wet on event date, dry at baseline): "
             f"{stats.get('new_water', {}).get('hectares', 0):,.0f} ha\n"
             f"Measured PERMANENT water (wet on both dates): "
             f"{stats.get('permanent_water', {}).get('hectares', 0):,.0f} ha\n"
             f"Comparable area: {payload['comparable_pct']}% of the AOI was cloud-free on BOTH "
             f"dates and could be compared; the rest is excluded, never assumed dry\n"
             f"Largest affected clusters: " + "; ".join(
                 f"{c['hectares']:,.0f} ha at {c['lat']:.4f}N {c['lon']:.4f}E" for c in top))

    content = [{"type": "text",
                "text": f"Officer question: {question}\n\nMEASUREMENTS\n{facts}\n\n"
                        f"Image 1 = {tile['date']} (event). "
                        f"Image 2 = {payload['baseline_date']} (baseline). "
                        f"Event-tile optical cloud ~{(tile['cloud'] or 0):.0%}."},
               {"type": "image_url", "image_url": {"url": data_url(tile["optical_path"])}}]
    base = db.tile(payload["baseline_tile_id"]) if payload["baseline_tile_id"] else None
    if base:
        content.append({"type": "image_url", "image_url": {"url": data_url(base["optical_path"])}})

    try:
        out = json.loads(groq([{"role": "system", "content": VISION},
                               {"role": "user", "content": content}], VLM, json_mode=True))
    except Exception as e:
        db.log_query(question, place, tile["id"], None, None, int((time.time() - t0) * 1000), False)
        return {"error": f"Vision model failed ({e})."}

    ms = int((time.time() - t0) * 1000)
    db.log_query(question, place, tile["id"], out.get("answer"), top, ms, True)
    return {"answer": out.get("answer", ""), "headline": out.get("headline", ""),
            "ms": ms, **payload}


@app.get("/api/aois")
def aois():
    out = {}
    for t in db.tiles():
        if db.detections(t["id"]):
            out.setdefault(t["aoi"], []).append(
                {"tile_id": t["id"], "date": t["date"],
                 "lat": round((t["lat0"] + t["lat1"]) / 2, 4),
                 "lon": round((t["lon0"] + t["lon1"]) / 2, 4)})
    return out


@app.get("/api/analysis/{tile_id}")
def api_analysis(tile_id: str):
    return analysis(tile_id) if db.tile(tile_id) else {"error": "unknown tile"}


@app.get("/api/history")
def history():
    return db.recent_queries(25)


@app.get("/api/report/{tile_id}", response_class=PlainTextResponse)
def report(tile_id: str):
    if not db.tile(tile_id):
        return "unknown tile"
    a = analysis(tile_id)
    t, s = a["tile"], a["summary"]
    sar = ("placeholder - Bhoonidhi credentials required"
           if "placeholder" in (t["note"] or "") else t["sar_path"])
    lines = [
        "SATQUERY AI - SURFACE WATER CHANGE REPORT", "=" * 56,
        f"Area of interest : {t['aoi']}",
        f"Event date       : {t['date']}",
        f"Baseline date    : {a['baseline_date']}",
        f"Bounding box     : {t['lon0']}, {t['lat0']} to {t['lon1']}, {t['lat1']} (WGS84)",
        f"Centre           : {a['centroid']['lat']}N, {a['centroid']['lon']}E",
        f"Water product    : NASA OPERA DSWx-HLS, 30 m",
        f"Optical imagery  : {t['sensor']}",
        f"SAR              : {sar}",
        "", "MEASURED EXTENT", "-" * 56,
        f"New water (wet on event, dry at baseline) : "
        f"{s.get('new_water', {}).get('hectares', 0):>12,.1f} ha",
        f"Permanent water (wet on both dates)       : "
        f"{s.get('permanent_water', {}).get('hectares', 0):>12,.1f} ha",
        f"Water cells detected                      : {len(a['cells']):>12}",
        f"AOI comparable on both dates              : "
        f"{str(a['comparable_pct']) + ' %':>12}",
        "", "LARGEST AFFECTED CLUSTERS", "-" * 56]
    for i, c in enumerate(a["clusters"][:10], 1):
        lines.append(f"{i:>2}. {c['hectares']:>9,.1f} ha  centre {c['lat']:.4f}N {c['lon']:.4f}E  "
                     f"({c['cells']} cells)")
    lines += ["", "METHOD", "-" * 56,
              "Water is classified per pixel on both dates from NASA OPERA DSWx-HLS. Only pixels",
              "that were cloud-free on BOTH dates are compared, so cloud is never counted as dry",
              "land. Each map cell is classified new_water (wet on event, dry at baseline) or",
              "permanent_water (wet on both). Areas use local metres-per-degree at this latitude.",
              "", "LIMITATIONS", "-" * 56,
              "Optical-derived water extent is unavailable under monsoon cloud, which is exactly",
              "when flooding peaks. Replacing the DSWx input with Bhoonidhi Sentinel-1 / EOS-04",
              "SAR removes that limitation; the change-detection method is unchanged.",
              "", f"Generated {time.strftime('%Y-%m-%d %H:%M:%S')}"]
    return "\n".join(lines)


UPLOADS = ROOT / "data" / "uploads"
_CACHE = {}   # upload_id -> (meta, rgb) so analysis does not re-decode the raster


@app.post("/api/upload")
async def upload(file: UploadFile = File(...)):
    """Accept a raster, validate the format, return metadata + a browser preview."""
    UPLOADS.mkdir(parents=True, exist_ok=True)
    name = pathlib.Path(file.filename or "upload").name
    ext = pathlib.Path(name).suffix.lower()
    if ext not in tools.SUPPORTED:
        return {"error": f"Unsupported format '{ext}'. Accepted: "
                         f"{', '.join(sorted(tools.SUPPORTED))}"}
    uid = f"{int(time.time()*1000)}_{name}"
    dest = UPLOADS / uid
    dest.write_bytes(await file.read())
    try:
        meta, rgb, _ = tools.load_image(dest)
    except Exception as e:
        dest.unlink(missing_ok=True)
        return {"error": f"Could not read {name}: {e}"}
    _CACHE[uid] = (meta, rgb)
    return {"id": uid, "name": name, "meta": meta, "preview": tools.to_data_url(rgb, 900)}


@app.get("/api/samples")
def samples():
    """Real Sentinel-2 tiles already on disk, so the app is demoable without hunting
    for files. Optical and SAR-placeholder pairs from two Assam AOIs."""
    out = []
    for f in sorted((ROOT / "data" / "tiles").glob("*.png")):
        aoi, date, kind = f.stem.split("_", 2)
        if "sar" in kind:
            continue          # the bundled SAR tiles are labelled placeholders, not radar -
        out.append({"file": f.name, "aoi": aoi.title(), "date": date,   # offering them as a
                    "kind": "optical", "url": f"/data/tiles/{f.name}"}) # sample would mislead
    return out


@app.post("/api/use-sample")
def use_sample(payload: dict):
    """Register an on-disk sample as though it had been uploaded."""
    name = pathlib.Path(str(payload.get("file", ""))).name
    src = ROOT / "data" / "tiles" / name
    if not src.exists():
        return {"error": f"No sample named {name}"}
    meta, rgb, _ = tools.load_image(src)
    _CACHE[name] = (meta, rgb)
    return {"id": name, "name": name, "meta": meta, "preview": tools.to_data_url(rgb, 900)}


class Live(BaseModel):
    place: str
    date: str = ""
    span: float = 0.35          # degrees around the geocoded point
    layer: str = "viirs"


@app.post("/api/live")
def live(body: Live):
    """Pull near-real-time imagery for a place straight from NASA GIBS.

    VIIRS true colour is published within a few hours of overpass, so this is live
    satellite data rather than a stored sample. Walks back day by day until a date
    with actual coverage is found (the newest scene may not be published yet)."""
    place = body.place.strip()
    if not place:
        return {"error": "Type a place name."}
    pt = geocode(place)
    if not pt:
        return {"error": f"Could not find '{place}'."}
    lon, lat = pt
    span = max(0.05, min(float(body.span), 3.0))
    bbox = [lon - span, lat - span / 2, lon + span, lat + span / 2]

    start = (datetime.date.fromisoformat(body.date) if body.date
             else datetime.date.today())
    layer = fetch_tiles.LAYERS.get(body.layer, fetch_tiles.LAYERS["viirs"])
    UPLOADS.mkdir(parents=True, exist_ok=True)

    for back in range(0, 10):                     # newest scenes may not be published yet
        d = (start - datetime.timedelta(days=back)).isoformat()
        try:
            png = fetch_tiles.get_map(bbox, d, layer)
        except Exception:
            continue
        cover, cloud = fetch_tiles.stats(png)
        if cover < 0.5:
            continue
        uid = f"live_{place.lower().replace(' ', '-')}_{d}.png"
        (UPLOADS / uid).write_bytes(png)
        meta, rgb, _ = tools.load_image(UPLOADS / uid)
        meta.update(georeferenced=True, crs="EPSG:4326", bounds=bbox,
                    source=layer, acquired=d, place=place, cloud=cloud)
        _CACHE[uid] = (meta, rgb)
        return {"id": uid, "name": f"{place} {d}", "meta": meta,
                "preview": tools.to_data_url(rgb, 900),
                "note": f"NASA GIBS {layer}, acquired {d}, ~{cloud:.0%} cloud"}
    return {"error": f"No usable {layer} imagery for {place} in the last 10 days "
                     f"(try a wider area or an older date)."}


class Analyze(BaseModel):
    q: str
    ids: list[str] = []


@app.post("/api/analyze")
def analyze(body: Analyze):
    imgs = []
    for uid in body.ids[:2]:
        if uid not in _CACHE:
            path = UPLOADS / uid
            if not path.exists():
                return {"error": f"Upload {uid} not found - please re-upload."}
            meta, rgb, _ = tools.load_image(path)
            _CACHE[uid] = (meta, rgb)
        meta, rgb = _CACHE[uid]
        imgs.append({"meta": meta, "rgb": rgb, "name": uid.split("_", 1)[-1]})
    if not imgs:
        return {"error": "Upload at least one image first."}
    if not body.q.strip():
        return {"error": "Ask a question about the image(s)."}

    t0 = time.time()
    out = agent.run(body.q.strip(), imgs, groq, VLM, TXT)
    out["ms"] = int((time.time() - t0) * 1000)
    out["images"] = [{"name": i["name"], "meta": i["meta"]} for i in imgs]
    db.log_query(body.q.strip(), out.get("task"), None,
                 out.get("answer"), out.get("boxes"), out["ms"], "error" not in out)
    return out


@app.post("/api/report-analysis")
def report_analysis(payload: dict):
    """Plain-text report of an analysis run, including the execution trace."""
    L = ["SATQUERY AI - ANALYSIS REPORT", "=" * 60,
         f"Question    : {payload.get('question','')}",
         f"Task        : {payload.get('task','')} - {payload.get('task_desc','')}",
         f"Generated   : {time.strftime('%Y-%m-%d %H:%M:%S')}", ""]
    for im in payload.get("images", []):
        m = im.get("meta", {})
        L += [f"INPUT: {im.get('name')}",
              f"  modality={m.get('modality')} bands={m.get('bands')} dtype={m.get('dtype')} "
              f"size={m.get('width')}x{m.get('height')} driver={m.get('driver')}",
              f"  georeferenced={m.get('georeferenced')} crs={m.get('crs')}",
              f"  bounds={m.get('bounds')}"]
    L += ["", "ANSWER", "-" * 60, payload.get("answer", ""), "", "MEASURED FINDINGS", "-" * 60]
    for name, r in (payload.get("results") or {}).items():
        L.append(f"[{name}] model={r.get('model')} confidence={r.get('confidence')}")
        L.append(f"  {r.get('summary','')}")
        for k, v in (r.get("metrics") or {}).items():
            L.append(f"    {k}: {v}")
    L += ["", "EXECUTION TRACE", "-" * 60]
    for st in (payload.get("trace") or {}).get("steps", []):
        L.append(f"{st['n']:>2}. {st['step']:<24} model={st.get('model')}  {st.get('ms')}ms")
        if st.get("params"):
            L.append(f"      params: {st['params']}")
        if st.get("note"):
            L.append(f"      note:   {st['note']}")
    L += ["", "METHOD AND LIMITS", "-" * 60,
          "Land cover and fusion use published RGB/backscatter index rules, not a trained",
          "classifier. Change detection thresholds each scene against its own noise floor.",
          "All percentages are measured from pixels; the language model narrates those",
          "numbers and never estimates them.", ""]
    return PlainTextResponse("\n".join(L))


(ROOT / "data" / "tiles").mkdir(parents=True, exist_ok=True)   # absent on a fresh clone
app.mount("/data", StaticFiles(directory=ROOT / "data"), name="data")


@app.get("/")
def home():
    return FileResponse(ROOT / "web" / "index.html")
