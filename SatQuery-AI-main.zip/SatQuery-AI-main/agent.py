"""Agentic controller.

Interprets the query, validates the inputs, selects specialist tools from the registry,
executes them, and integrates the outputs into one evidence-grounded answer.

Every step is appended to an execution trace: step, tool/model, parameters, duration.
The trace is the observable record of what actually ran - the reasoning that chose it is
not recorded, because only what executed can be audited.
"""
import json, time
import tools

TASKS = {
    "vqa":          "answer a question about a single image",
    "caption":      "describe / caption a single image",
    "grounding":    "locate and highlight a specific object or region named in the query",
    "landcover":    "classify land cover and report class percentages",
    "change":       "describe what changed between two dates (bi-temporal pair)",
    "optical_sar":  "extract complementary information from an optical + SAR pair",
}

CLASSIFY = (
    "You route remote-sensing queries to a specialist tool. Reply with JSON only:\n"
    '{"task": "<one of: ' + "|".join(TASKS) + '>", "target": "<object named in the query, or null>"}\n'
    "Rules:\n"
    "- Two images supplied and the query asks what changed / compares dates -> change\n"
    "- Two images and one is SAR -> optical_sar\n"
    "- One image, query names a specific object to find/highlight/show -> grounding\n"
    "- One image, query asks to describe the scene -> caption\n"
    "- Query asks about land cover, area, or how much of something -> landcover\n"
    "- Otherwise, a question about one image -> vqa"
)

ANSWER = """You are a remote-sensing analyst. You are given a user question, the outputs of
specialist tools that have already run, and the image(s).

The tool numbers are MEASURED. Quote them exactly. Never re-estimate a percentage or an area
from looking at the picture, and never contradict a tool.

Answer in 2-4 plain sentences: what the tools found, where it is in the scene, and what it
means for the user. If a tool reported low confidence or a compatibility warning, say so.

JSON only: {"answer": "...", "headline": "one short sentence with the key number"}"""

TARGET = ('Name the single object or feature the user wants located. '
          'JSON only: {"target": "<short noun phrase, or null>"}')

GROUND = """Locate the object the user names, in the image. Reply JSON only:
{"found": true/false, "label": "short label",
 "boxes": [[x0,y0,x1,y1]], "note": "one sentence"}
Coordinates are normalised 0-1 with the origin at the TOP-LEFT. Max 4 boxes.
If the object is not visible, return found=false and an empty list rather than guessing."""


class Trace:
    def __init__(self):
        self.steps = []
        self.t0 = time.time()

    def add(self, step, model, params=None, note=None, ms=None):
        self.steps.append({"n": len(self.steps) + 1, "step": step, "model": model,
                           "params": params or {}, "note": note,
                           "ms": ms if ms is not None else int((time.time() - self.t0) * 1000)})

    def dump(self):
        return {"steps": self.steps, "total_ms": int((time.time() - self.t0) * 1000)}


# Rule-based routing. The input configuration plus a few keywords settle almost every
# real query, so the classifier LLM call is skipped - it was costing a full round trip
# (and a slice of the rate limit) to produce an answer the guard rails then overrode.
_RULES = [
    ("change",      ("chang", "differ", "compare", "before", "after", "increas",
                     "decreas", "since", "grown", "shrunk", "between these")),
    ("optical_sar", ("sar", "radar", "backscatter", "through cloud", "all-weather")),
    ("grounding",   ("highlight", "locate", "find the", "show me", "where is",
                     "point to", "mark the", "identify the")),
    ("landcover",   ("land cover", "landcover", "how much", "percentage", "percent",
                     "area of", "coverage", "breakdown", "classify")),
    ("caption",     ("describe", "caption", "what is in", "what do you see", "summarise",
                     "summarize", "overview")),
]


def _rule_route(question, mods):
    ql = question.lower()
    hits = [task for task, keys in _RULES if any(k in ql for k in keys)]
    two = len(mods) >= 2
    cross = "SAR" in mods and "optical" in mods

    if two:
        if "optical_sar" in hits or (cross and "change" not in hits):
            return "optical_sar", None
        return "change", None                     # two images, no SAR -> compare dates
    for t in hits:
        if t not in ("change", "optical_sar"):
            return t, None
    return ("landcover" if hits else "vqa"), None


def _target(question, groq, txt_model):
    """Only asked when the query names something to locate."""
    try:
        out = json.loads(groq([{"role": "system", "content": TARGET},
                               {"role": "user", "content": question}], txt_model, json_mode=True))
        t = out.get("target")
        return t if t and str(t).lower() != "null" else None
    except Exception:
        return None


def classify(question, images, groq, txt_model, allow_llm=True):
    """Rules first; the LLM is a fallback only when the rules find nothing to go on."""
    mods = [i["meta"]["modality"] for i in images]
    task, target = _rule_route(question, mods)
    if task != "vqa" or not allow_llm:
        return task, target, "rules"
    try:
        out = json.loads(groq([{"role": "system", "content": CLASSIFY},
                               {"role": "user", "content": question}], txt_model, json_mode=True))
        t = out.get("task")
        if t in TASKS and t not in ("change", "optical_sar"):
            return t, out.get("target"), txt_model
    except Exception:
        pass
    return task, target, "rules"


def run(question, images, groq, vlm_model, txt_model):
    """images: [{"meta":..., "rgb": ndarray, "name": str}, ...]"""
    tr = Trace()
    task, target, router = classify(question, images, groq, txt_model)
    if task == "grounding" and not target:
        target = _target(question, groq, txt_model)
    tr.add("interpret query", router,
           {"images": len(images), "modalities": [i["meta"]["modality"] for i in images]})
    tr.add("task classified", router, {"task": task, "target": target},
           note="routed without an LLM call" if router == "rules" else None)

    # ---- input validation -------------------------------------------------
    compat = {"ok": True, "issues": [], "notes": []}
    need = 2 if task in ("change", "optical_sar") else 1
    if len(images) < need:
        return {"error": f"'{TASKS[task]}' needs {need} image(s); {len(images)} supplied.",
                "trace": tr.dump(), "task": task}
    if need == 2:
        compat = tools.check_pair(images[0]["meta"], images[1]["meta"])
        tr.add("compatibility check", "raster metadata",
               {"pair": [images[0]["name"], images[1]["name"]]},
               note="; ".join(compat["issues"] + compat["notes"]) or "compatible")
        if not compat["ok"]:
            return {"error": "Incompatible pair: " + "; ".join(compat["issues"]),
                    "trace": tr.dump(), "task": task, "compat": compat}

    # ---- specialist execution ---------------------------------------------
    results, overlays = {}, []
    t = time.time()

    if task == "change":
        r = tools.change_detection(images[0]["rgb"], images[1]["rgb"])
        results["change"] = r
    elif task == "optical_sar":
        opt = next((i for i in images if i["meta"]["modality"] == "optical"), images[0])
        sar = next((i for i in images if i["meta"]["modality"] == "SAR"), images[1])
        r = tools.optical_sar_fusion(opt["rgb"], sar["rgb"])
        results["optical_sar"] = r
    else:
        r = tools.landcover(images[0]["rgb"], images[0]["meta"]["modality"])
        results[task] = r          # key by task so callers find it for vqa/caption too

    tr.add(f"tool: {task}", r["model"], r["params"],
           note=r["summary"], ms=int((time.time() - t) * 1000))
    overlays.append({"task": task, "png": r["overlay"], "label": r["model"]})

    # ---- grounding (adds boxes on top of whatever ran) --------------------
    boxes = []
    if task == "grounding" or target:
        t = time.time()
        try:
            g = json.loads(groq([{"role": "system", "content": GROUND},
                                 {"role": "user", "content": [
                                     {"type": "text", "text": f"Find: {target or question}"},
                                     {"type": "image_url",
                                      "image_url": {"url": tools.to_data_url(images[0]["rgb"], px=448)}}]}],
                                vlm_model, json_mode=True))
            if g.get("found"):
                boxes = [b for b in g.get("boxes", []) if len(b) == 4][:4]
            results["grounding"] = {"summary": g.get("note", ""), "metrics": {"label": g.get("label"),
                                    "found": bool(g.get("found"))}, "confidence": None,
                                    "model": vlm_model, "params": {"target": target}}
            tr.add("tool: grounding", vlm_model, {"target": target or question},
                   note=g.get("note") or ("found" if boxes else "not found"),
                   ms=int((time.time() - t) * 1000))
        except Exception as e:
            tr.add("tool: grounding", vlm_model, {}, note=f"failed: {e}")

    # ---- integration: the model narrates measured findings ----------------
    facts = json.dumps({k: {"summary": v["summary"], "metrics": v.get("metrics"),
                            "confidence": v.get("confidence")} for k, v in results.items()},
                       indent=1)[:4000]
    # Only send pixels when the answer depends on looking at them. Change, land cover
    # and fusion are answered from measured statistics, so they go to the cheap text
    # model - about 500 tokens instead of ~4,600 for two images, which keeps a
    # free-tier daily quota usable for a whole demo instead of a handful of queries.
    needs_vision = task in ("vqa", "caption", "grounding")
    prompt = (f"User question: {question}\nTask selected: {task}\n"
              f"Compatibility: {'; '.join(compat['issues'] + compat['notes']) or 'ok'}\n\n"
              f"TOOL OUTPUTS (measured - quote these)\n{facts}")
    if needs_vision:
        content = [{"type": "text", "text": prompt}]
        for im in images[:2]:
            content.append({"type": "image_url",
                            "image_url": {"url": tools.to_data_url(im["rgb"], px=448)}})
        model = vlm_model
    else:
        content = prompt + ("\n\nYou are not shown the images. Describe only what the "
                            "measurements above support, and where in the frame they sit.")
        model = txt_model
    t = time.time()
    try:
        out = json.loads(groq([{"role": "system", "content": ANSWER},
                               {"role": "user", "content": content}], model, json_mode=True))
        answer, headline = out.get("answer", ""), out.get("headline", "")
    except Exception as e:
        # LLM unavailable (rate limit, outage): fall back to the measured tool summary.
        # No headline - it would just repeat the answer verbatim in the UI.
        answer = results[task]["summary"] if task in results else str(e)
        headline = ""
    tr.add("integrate + narrate", model,
           {"tools_combined": list(results),
            "images_sent": len(images[:2]) if needs_vision else 0},
           ms=int((time.time() - t) * 1000))

    return {"task": task, "task_desc": TASKS[task], "answer": answer, "headline": headline,
            "results": results, "overlays": overlays, "boxes": boxes,
            "confidence": results.get(task, {}).get("confidence"),
            "compat": compat, "trace": tr.dump()}
