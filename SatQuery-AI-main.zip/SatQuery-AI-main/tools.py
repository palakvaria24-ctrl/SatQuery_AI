"""Specialist remote-sensing tools. The agent picks from this registry.

Every tool returns the same envelope so the controller can combine outputs uniformly:

    {"summary": str, "metrics": {...}, "overlay": <PNG data-url or None>,
     "confidence": float|None, "params": {...}, "model": str}

Confidence is MEASURED where a measurement exists (fraction of pixels that fall clearly
on one side of a threshold, or fraction of pixels above the change noise floor). Tools
whose output is generated text report confidence None - a language model's fluency is not
a confidence score, and inventing one would be dishonest.
"""
import base64, io, math
import numpy as np
from PIL import Image
from scipy import ndimage

# ── image loading / compatibility ─────────────────────────────────────────────

SUPPORTED = {".tif", ".tiff", ".png", ".jpg", ".jpeg"}


def load_image(path):
    """Read GeoTIFF/TIFF/PNG/JPEG -> metadata + RGB uint8 array + raw band stack."""
    path = str(path)
    meta = {"path": path, "georeferenced": False, "crs": None, "transform": None,
            "bounds": None, "bands": None, "dtype": None, "driver": None}
    lower = path.lower()

    if lower.endswith((".tif", ".tiff")):
        import rasterio
        from rasterio.enums import Resampling
        with rasterio.open(path) as src:
            meta.update(bands=src.count, dtype=str(src.dtypes[0]), driver=src.driver,
                        width=src.width, height=src.height)
            if src.crs is not None:
                b = src.bounds
                meta.update(georeferenced=True, crs=str(src.crs),
                            transform=list(src.transform)[:6],
                            bounds=[b.left, b.bottom, b.right, b.top])
            cap = 1024
            scale = min(1.0, cap / max(src.width, src.height))
            out_h, out_w = max(1, int(src.height * scale)), max(1, int(src.width * scale))
            stack = src.read(out_shape=(src.count, out_h, out_w),
                             resampling=Resampling.bilinear).astype(np.float32)
    else:
        img = Image.open(path)
        meta.update(bands=len(img.getbands()), dtype="uint8", driver=img.format,
                    width=img.width, height=img.height)
        img.thumbnail((1024, 1024), Image.LANCZOS)
        stack = np.asarray(img.convert("RGB"), np.float32).transpose(2, 0, 1)

    rgb = _to_rgb(stack)
    meta["modality"] = "SAR" if _looks_like_sar(stack) else "optical"
    meta["preview_size"] = [rgb.shape[1], rgb.shape[0]]
    return meta, rgb, stack


def _stretch(a):
    """2-98% percentile stretch - raw satellite DN ranges are not 0-255."""
    lo, hi = np.percentile(a, 2), np.percentile(a, 98)
    if hi <= lo:
        lo, hi = float(a.min()), float(a.max() or 1)
    return np.clip((a - lo) / max(hi - lo, 1e-6), 0, 1)


def _to_rgb(stack):
    if stack.shape[0] >= 3:
        chans = [_stretch(stack[i]) for i in range(3)]
    else:
        g = _stretch(stack[0])
        chans = [g, g, g]
    return (np.stack(chans, -1) * 255).astype(np.uint8)


def _looks_like_sar(stack):
    """Single-band, or effectively grey with the heavy-tailed histogram SAR produces."""
    if stack.shape[0] == 1:
        return True
    if stack.shape[0] >= 3:
        spread = np.mean(np.abs(stack[0] - stack[1])) + np.mean(np.abs(stack[1] - stack[2]))
        return spread < 1.0
    return False


def check_pair(meta_a, meta_b):
    """Compatibility report for a two-image request. Never silently proceeds on a mismatch."""
    issues, notes = [], []
    if meta_a["preview_size"] != meta_b["preview_size"]:
        notes.append(f"different rasters ({meta_a['preview_size']} vs {meta_b['preview_size']}) "
                     f"- resampled to the smaller grid for comparison")
    if meta_a["georeferenced"] and meta_b["georeferenced"]:
        if meta_a["crs"] != meta_b["crs"]:
            issues.append(f"CRS mismatch: {meta_a['crs']} vs {meta_b['crs']}")
        else:
            notes.append(f"both georeferenced in {meta_a['crs']}")
        ba, bb = meta_a["bounds"], meta_b["bounds"]
        if ba and bb:
            ox = min(ba[2], bb[2]) - max(ba[0], bb[0])
            oy = min(ba[3], bb[3]) - max(ba[1], bb[1])
            if ox <= 0 or oy <= 0:
                issues.append("bounding boxes do not overlap - not the same area")
            else:
                notes.append("bounding boxes overlap")
    elif meta_a["georeferenced"] != meta_b["georeferenced"]:
        notes.append("only one image carries georeferencing - assuming co-registered")
    else:
        notes.append("no georeferencing - assuming the pair is already co-registered")
    return {"ok": not issues, "issues": issues, "notes": notes}


def _align(a, b):
    h = min(a.shape[0], b.shape[0])
    w = min(a.shape[1], b.shape[1])
    return (np.asarray(Image.fromarray(a).resize((w, h), Image.BILINEAR), np.float32),
            np.asarray(Image.fromarray(b).resize((w, h), Image.BILINEAR), np.float32))


def _png(rgba):
    buf = io.BytesIO()
    Image.fromarray(rgba, "RGBA").save(buf, "PNG")
    return "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode()


def to_data_url(rgb, px=768, quality=82):
    img = Image.fromarray(rgb)
    if max(img.size) > px:
        img.thumbnail((px, px), Image.LANCZOS)
    buf = io.BytesIO()
    img.save(buf, "JPEG", quality=quality)
    return "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()


# ── land cover (spectral index heuristics, no training required) ──────────────

CLASS_COLORS = {"vegetation": (60, 160, 70), "water": (40, 110, 210),
                "built-up": (225, 85, 60), "bare/soil": (200, 170, 105)}


def landcover(rgb, modality="optical"):
    """Per-pixel land cover from RGB indices. These are published rules of thumb, not a
    trained classifier - stated plainly so nobody mistakes it for a benchmarked model."""
    a = rgb.astype(np.float32) / 255.0
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    bright = a.mean(-1)
    sat = a.max(-1) - a.min(-1)

    if modality == "SAR":
        # SAR: smooth surfaces scatter away (dark = water), buildings double-bounce (bright)
        water = bright < 0.18
        built = bright > 0.62
        veg = (~water) & (~built) & (bright > 0.30)
        bare = ~(water | built | veg)
        margin = np.abs(bright - 0.18) + np.abs(bright - 0.62)
    else:
        exg = 2 * g - r - b                      # excess green: vegetation vigour
        ndwi_like = (g - r) / (g + r + 1e-6)     # green-red water proxy for RGB-only data
        water = (bright < 0.42) & (b >= r * 0.95) & (exg < 0.10)
        veg = (exg > 0.06) & (~water)
        built = (~veg) & (~water) & (sat < 0.18) & (bright > 0.38)
        bare = ~(veg | water | built)
        margin = np.abs(exg - 0.06) + np.abs(ndwi_like)

    masks = {"vegetation": veg, "water": water, "built-up": built, "bare/soil": bare}
    total = rgb.shape[0] * rgb.shape[1]
    pct = {k: round(100 * float(m.sum()) / total, 1) for k, m in masks.items()}

    overlay = np.zeros((*rgb.shape[:2], 4), np.uint8)
    for name, m in masks.items():
        overlay[m] = (*CLASS_COLORS[name], 130)

    # Labelled regions: the largest contiguous blob(s) per class, for on-image tags.
    regions = []
    h, w = rgb.shape[:2]
    for name, m in masks.items():
        if m.sum() < total * 0.004:
            continue
        lab, n = ndimage.label(ndimage.binary_opening(m, np.ones((5, 5))))
        if not n:
            continue
        sizes = ndimage.sum(m, lab, range(1, n + 1))
        for idx in np.argsort(sizes)[::-1][:2]:
            if sizes[idx] < total * 0.004:
                break
            sl = ndimage.find_objects(lab)[idx]
            cx = round((sl[1].start + sl[1].stop) / (2 * w), 4)
            cy = round((sl[0].start + sl[0].stop) / (2 * h), 4)
            regions.append({"label": name, "color": "#%02x%02x%02x" % CLASS_COLORS[name],
                            "area_percent": round(100 * float(sizes[idx]) / total, 1),
                            "box": [round(sl[1].start / w, 4), round(sl[0].start / h, 4),
                                    round(sl[1].stop / w, 4), round(sl[0].stop / h, 4)],
                            "centroid": [cx, cy]})
    regions.sort(key=lambda r: -r["area_percent"])

    # Confidence: how decisively pixels sit away from the decision boundary.
    conf = float(np.clip(np.mean(margin > 0.05), 0, 1))
    dominant = max(pct, key=pct.get)
    return {"summary": f"{dominant} dominates at {pct[dominant]}% of the scene "
                       f"({', '.join(f'{k} {v}%' for k, v in pct.items())}).",
            "metrics": {"class_percent": pct, "dominant": dominant, "regions": regions[:6]},
            "overlay": _png(overlay), "confidence": round(conf, 3),
            "params": {"modality": modality, "rules": "RGB spectral indices (ExG, brightness, saturation)"},
            "model": "rule-based spectral index classifier"}


# ── bi-temporal change ────────────────────────────────────────────────────────

# Plain-language change types a non-expert can read, each with its own colour.
CHANGE_TYPES = {
    "New construction / bare": (232, 69, 44),
    "Cleared land":            (232, 176, 33),
    "New vegetation":          (60, 160, 70),
    "New water / flooding":    (47, 111, 208),
    "Other change":            (150, 110, 200),
}


def _change_kind(before_rgb, after_rgb):
    """Classify a changed blob from how brightness and greenness moved."""
    d_bright = float(after_rgb.mean() - before_rgb.mean())
    green = lambda c: 2 * c[1] - c[0] - c[2]
    d_green = float(green(after_rgb) - green(before_rgb))
    if d_green > 12:
        return "New vegetation"
    if d_green < -12 and d_bright > 0:
        return "Cleared land"
    if d_bright > 18:
        return "New construction / bare"
    if d_bright < -18:
        return "New water / flooding"
    return "Other change"


def change_detection(rgb_a, rgb_b, sensitivity=2.5, min_blob=40):
    """Change magnitude between two co-registered dates, thresholded above the scene's
    own noise floor, grouped into blobs, then classified into plain-language types."""
    A, B = _align(rgb_a, rgb_b)
    diff = np.linalg.norm(B - A, axis=-1) / (255 * math.sqrt(3))
    mu, sd = float(diff.mean()), float(diff.std())
    thr = mu + sensitivity * sd                      # adaptive: scene is its own control
    mask = diff > thr

    mask = ndimage.binary_opening(mask, np.ones((3, 3)))
    lab, n = ndimage.label(mask)
    if n:
        sizes = ndimage.sum(mask, lab, range(1, n + 1))
        mask = np.isin(lab, 1 + np.flatnonzero(sizes >= min_blob))
        lab, n = ndimage.label(mask)

    total = mask.size
    changed_pct = round(100 * float(mask.sum()) / total, 2)
    h, w = mask.shape

    blobs, kind_mask = [], {}
    if n:
        for i, sl in enumerate(ndimage.find_objects(lab), 1):
            m = lab[sl] == i
            if m.sum() < min_blob:
                continue
            kind = _change_kind(A[sl][m].mean(0), B[sl][m].mean(0))
            full = np.zeros_like(mask)
            full[sl] = m
            kind_mask[kind] = kind_mask.get(kind, np.zeros_like(mask)) | full
            cx = round((sl[1].start + sl[1].stop) / (2 * w), 4)
            cy = round((sl[0].start + sl[0].stop) / (2 * h), 4)
            blobs.append({"kind": kind, "label": kind,
                          "color": "#%02x%02x%02x" % CHANGE_TYPES[kind],
                          "pixels": int(m.sum()),
                          "area_percent": round(100 * float(m.sum()) / total, 2),
                          "box": [round(sl[1].start / w, 4), round(sl[0].start / h, 4),
                                  round(sl[1].stop / w, 4), round(sl[0].stop / h, 4)],
                          "centroid": [cx, cy]})
    blobs.sort(key=lambda x: -x["pixels"])

    # Overlay coloured BY CHANGE TYPE. Dilated a little so single-pixel changes stay
    # visible when a 1024px scene is drawn a few hundred pixels wide - the dilation is
    # display-only; every number above comes from the undilated mask.
    overlay = np.zeros((*mask.shape, 4), np.uint8)
    for kind, km in kind_mask.items():
        vis = ndimage.binary_dilation(km, np.ones((5, 5)))
        overlay[vis] = (*CHANGE_TYPES[kind], 165)

    by_type = {}
    for b in blobs:
        by_type[b["kind"]] = round(by_type.get(b["kind"], 0) + b["area_percent"], 2)
    legend = [{"label": k, "color": "#%02x%02x%02x" % CHANGE_TYPES[k], "percent": v}
              for k, v in sorted(by_type.items(), key=lambda x: -x[1])]

    conf = float(np.clip((diff[mask].mean() - mu) / (sd * 4 + 1e-6), 0, 1)) if mask.any() else 0.0
    return {"summary": (f"{changed_pct}% of the scene changed across {len(blobs)} regions"
                        + (f"; mostly {legend[0]['label'].lower()}" if legend else "")),
            "metrics": {"changed_percent": changed_pct, "regions": len(blobs),
                        "by_type": by_type, "legend": legend,
                        "top_regions": blobs[:8]},
            "overlay": _png(overlay), "confidence": round(conf, 3),
            "params": {"sensitivity_sigma": sensitivity, "min_blob_px": min_blob,
                       "threshold": round(thr, 4), "noise_floor_mu": round(mu, 4),
                       "overlay_dilation_px": 2},
            "model": "adaptive-threshold change detector + connected components"}


# ── optical + SAR joint analysis ──────────────────────────────────────────────

def optical_sar_fusion(rgb_opt, rgb_sar):
    """Complementary extraction: SAR settles water and built-up through cloud; optical
    settles vegetation. Agreement between them is reported, not hidden."""
    O, S = _align(rgb_opt, rgb_sar)
    o = O / 255.0
    s = (S / 255.0).mean(-1)
    r, g, b = o[..., 0], o[..., 1], o[..., 2]
    exg = 2 * g - r - b

    sar_water = s < 0.18
    sar_built = s > 0.62
    opt_water = (o.mean(-1) < 0.42) & (b >= r * 0.95) & (exg < 0.10)
    opt_veg = exg > 0.06
    opt_cloud = (o.mean(-1) > 0.78) & ((o.max(-1) - o.min(-1)) < 0.10)

    total = s.size
    both_water = sar_water & opt_water
    agree = round(100 * float(both_water.sum()) / max(float(sar_water.sum()), 1), 1)
    hidden = sar_water & opt_cloud                    # SAR sees water where optical is blind

    overlay = np.zeros((*s.shape, 4), np.uint8)
    overlay[sar_built] = (225, 85, 60, 140)
    overlay[sar_water] = (40, 110, 210, 150)
    overlay[hidden] = (255, 200, 0, 190)

    pct = {"water (SAR)": round(100 * float(sar_water.sum()) / total, 1),
           "built-up (SAR)": round(100 * float(sar_built.sum()) / total, 1),
           "vegetation (optical)": round(100 * float(opt_veg.sum()) / total, 1),
           "cloud-obscured optical": round(100 * float(opt_cloud.sum()) / total, 1),
           "water under cloud (SAR only)": round(100 * float(hidden.sum()) / total, 1)}
    sar_masks = {
        "Water under cloud (SAR)": (hidden, (255, 200, 0)),
        "Built-up (SAR)": (sar_built, (225, 85, 60)),
        "Water (SAR)": (sar_water, (40, 110, 210))
    }
    regions = []
    h, w = s.shape[:2]
    for label, (mask, col) in sar_masks.items():
        if mask.sum() < total * 0.003:
            continue
        lab, n = ndimage.label(ndimage.binary_opening(mask, np.ones((5, 5))))
        if not n:
            continue
        sizes = ndimage.sum(mask, lab, range(1, n + 1))
        for idx in np.argsort(sizes)[::-1][:2]:
            if sizes[idx] < total * 0.003:
                break
            sl = ndimage.find_objects(lab)[idx]
            cx = round((sl[1].start + sl[1].stop) / (2 * w), 4)
            cy = round((sl[0].start + sl[0].stop) / (2 * h), 4)
            regions.append({"label": label, "color": "#%02x%02x%02x" % col,
                            "area_percent": round(100 * float(sizes[idx]) / total, 1),
                            "box": [round(sl[1].start / w, 4), round(sl[0].start / h, 4),
                                    round(sl[1].stop / w, 4), round(sl[0].stop / h, 4)],
                            "centroid": [cx, cy]})
    regions.sort(key=lambda r: -r["area_percent"])

    conf = float(np.clip(agree / 100, 0, 1))
    return {"summary": (f"SAR maps {pct['water (SAR)']}% water and {pct['built-up (SAR)']}% built-up; "
                        f"optical adds {pct['vegetation (optical)']}% vegetation. "
                        f"Sensors agree on {agree}% of SAR water"
                        + (f"; {pct['water under cloud (SAR only)']}% of the scene is water that "
                           f"optical could not see through cloud."
                           if pct["water under cloud (SAR only)"] > 0.05 else ".")),
            "metrics": {"class_percent": pct, "sensor_agreement_percent": agree, "regions": regions[:6]},
            "overlay": _png(overlay), "confidence": round(conf, 3),
            "params": {"sar_water_thr": 0.18, "sar_built_thr": 0.62, "exg_veg_thr": 0.06},
            "model": "cross-modal threshold fusion (SAR backscatter + optical ExG)"}


REGISTRY = {
    "landcover":    {"fn": landcover,          "inputs": 1, "desc": "per-pixel land-cover classification with class percentages"},
    "change":       {"fn": change_detection,   "inputs": 2, "desc": "bi-temporal change map, regions and change types"},
    "optical_sar":  {"fn": optical_sar_fusion, "inputs": 2, "desc": "joint optical+SAR extraction of water and built-up"},
}
