# SatQuery AI — SIH26167

An interactive vision-language assistant for remote-sensing imagery. Ask a plain-language
question about a place; get a decision-focused answer, measured hectares, and the affected
area drawn on a map with coordinates.

> **Is Majuli flooded?**
> 9,939 ha of new surface water measured on 2024-10-19 that was dry at the 2024-11-28
> baseline. Largest cluster 1,157 ha at 27.0464°N, 94.0110°E.

---

## 1. Stack (frontend / backend / database)

| Layer | Technology | File |
|---|---|---|
| Frontend | HTML + CSS + vanilla JS, Leaflet map, no build step | `web/index.html` |
| Backend | Python 3, FastAPI, Uvicorn — REST/JSON | `server.py` |
| Database | **SQLite** (`sqlite3`, Python standard library) — 3 tables | `db.py`, `data/satquery.db` |
| Processing | NumPy + Pillow raster analysis | `detect.py` |
| Ingest | NASA GIBS WMS client | `fetch_tiles.py` |
| ISRO data | Bhoonidhi STAC client (OAuth2) | `bhoonidhi.py` |
| AI | Groq — `qwen/qwen3.8-27b` (vision), `openai/gpt-oss-20b` (parsing) | `server.py` |
| Tests | 7 offline checks, no network or API key | `test_satquery.py` |

### Database schema

```
tiles       id, aoi, date, bbox, cloud, coverage, sensor, paths, cells_observed, cells_total
detections  tile_id -> tiles(id), baseline_tile_id, kind, cell bbox, hectares
queries     ts, question, place, tile_id, answer, regions, ms, ok      -- full audit trail
```

`detections` holds the map overlay — one row per classified grid cell. `queries` logs every
question asked with its latency, so the system has a real usage history, not just a UI.

### Request flow

```
question
  -> LLM extracts place + task              (openai/gpt-oss-20b, JSON mode)
  -> geocode place                          (Nominatim, India-restricted)
  -> retrieve covering tile                 (SQLite: name match, then point-in-bbox)
  -> load measured water statistics         (SQLite detections + clustering)
  -> vision LLM writes the briefing         (qwen3.8-27b, 2 images + measured facts)
  -> answer + red/blue cells + marker + report
```

---

## 2. What data is used

| Purpose | Source | Resolution | Auth |
|---|---|---|---|
| Surface-water extent (the red/blue overlay) | **NASA OPERA DSWx-HLS** via GIBS WMS | 30 m | none |
| True-colour imagery (what the VLM looks at) | **HLS S30** (Sentinel-2 harmonised) via GIBS WMS | 30 m | none |
| Place name → coordinates | OpenStreetMap Nominatim | — | none |
| Basemap | OpenStreetMap / Esri World Imagery | — | none |
| **SAR (all-weather)** | **ISRO Bhoonidhi** — `Sentinel-1A_SAR-IW_GRD`, `EOS-04_SAR-*` | 6–25 m | free account |
| Language + vision model | Groq API | — | API key |

All imagery is real and downloaded live. Nothing on the map is drawn for appearance.

---

## 3. How the numbers are produced

**The LLM never estimates area.** Hectares come from deterministic change detection; the
model only writes the narrative around measured values. This is the single most important
thing to be able to say when questioned.

1. Classify surface water per pixel on the **event** date and a **baseline** date
   (OPERA DSWx-HLS: open water, partial water, not water, cloud, fill).
2. Build a validity mask. Cloud/no-data pixels are **excluded**, never assumed dry —
   otherwise cloud would masquerade as a flood.
3. Compare only pixels observable on **both** dates.
4. Aggregate to a 64-cell-wide grid; a cell is classified when ≥40% of it is observable:
   - `new_water` — wet on event date, dry at baseline → **red** (excess inundation)
   - `permanent_water` — wet on both dates → **blue** (river channel)
5. Convert cells to hectares using local metres-per-degree at that latitude.
6. Group adjacent cells into clusters, ranked by area, each with a centroid coordinate.

Reported coverage (e.g. "30% of the AOI comparable") is shown in the UI and stated by the
model, so a partial result is never presented as a complete one.

---

## 4. Run it

```bash
git clone <repo-url> && cd satquery-ai
pip install -r requirements.txt

cp .env.example .env          # then fill in GROQ_API_KEY
export GROQ_API_KEY=...       # or just export it directly

python test_satquery.py       # 7 offline checks - no key or network needed
python fetch_tiles.py --aoi Majuli --bbox 93.90 26.90 94.30 27.10 \
                      --event 2024-10-19 --baseline 2024-11-28
python -m uvicorn server:app --port 8077      # http://localhost:8077
```

`data/` is gitignored and rebuilt by `fetch_tiles.py`, so a fresh clone downloads its own
imagery rather than shipping it. The tests need neither a key nor a network connection.

Adding a district is one command — no code changes.

### API

| Endpoint | Purpose |
|---|---|
| `POST /api/query` | question → answer + cells + clusters |
| `GET /api/aois` | analysed areas |
| `GET /api/analysis/{tile_id}` | full measured payload |
| `GET /api/report/{tile_id}` | downloadable text report |
| `GET /api/history` | query log from SQLite |

---

## 5. ISRO Bhoonidhi — needed, and why

**Verdict: yes, required.** It is the only source in this stack for ISRO SAR, and SAR is the
technical justification for the whole project.

The problem is provable in our own data: Majuli on its 2024 monsoon flood date measures
**100% cloud** in optical imagery, while the same area in the dry season measures **0%**.
Every optical product — including NASA's own flood layers — is blind exactly when a
disaster officer needs it. SAR sees through cloud.

`bhoonidhi.py` implements the documented flow against
`https://bhoonidhi-api.nrsc.gov.in` — verified reachable, returns 401 for bad credentials:

```
POST /auth/token     userId + password -> JWT (20 min) + refresh token, cached to disk
POST /data/search    STAC item-search, bbox + datetime + cql2-json Online=Y filter
GET  /download       streams the product
```

```bash
export BHOONIDHI_USER=... BHOONIDHI_PASS=...     # free self-registration, no approval wait
python bhoonidhi.py search --collection Sentinel-1A_SAR-IW_GRD \
    --bbox 93.90 26.90 94.30 27.10 --start 2024-10-01 --end 2024-10-31
```

To switch the pipeline to SAR, replace `detect.water_mask()` with a backscatter threshold
(water is specular → very dark in SAR). Gridding, hectares, clustering, database, map and
report are unchanged — and the system then works during an actual monsoon flood.

**Other APIs from the design doc:** VEDAS and MOSDAC are optional context layers, not needed
for the current two use cases. Bhuvan's gazetteer can replace Nominatim for official Indian
place names — a drop-in swap in `server.geocode()`, worth doing for an ISRO audience.

---

## 6. Likely questions

**What is actually AI here?** Two roles: the vision-language model reads the imagery and
writes the officer-facing briefing, and a smaller model parses free-text questions into a
place plus task. The measurements are classical remote sensing — deliberately, because a
disaster officer cannot act on a hallucinated number.

**Could the model invent a flood?** No. Hectares and coordinates come from OPERA DSWx-HLS
change detection stored in SQLite. The model receives them as facts and is instructed never
to re-estimate area from pixels.

**How do you know cloud is not counted as flood?** Only pixels cloud-free on both dates are
compared. `test_cloud_is_never_counted_as_dry` asserts that a wet event date against a fully
clouded baseline yields **zero** detections rather than a false flood.

**Why is part of the map empty?** That area was not observable on both dates. It is reported
as unobserved, not as dry — the "AOI comparable" figure in the panel.

**Does it only work for one place?** No. Any AOI is one `fetch_tiles.py` command. Two are
loaded (Majuli, Kaziranga); retrieval is by geocoded coordinate, not a hardcoded list.

**Why Groq and not a fine-tuned GeoChat?** Honest trade-off. Fine-tuning GeoChat needs a GPU
and weeks; a hosted vision model gives a working system now. The cost is that fusion is
**prompt-level** (both images in one call), not a trained fusion adapter — see below.

**What does it cost to run?** Groq's vision model bills images at $0. A query is ~6 s
end to end.

---

## 7. Honest limitations

State these plainly — the design doc argues correctly that this is a strength for an
ISRO-sponsored problem statement.

1. **SAR is a placeholder.** Optical and water-extent data are real; the SAR channel is a
   stamped placeholder until Bhoonidhi credentials exist. The system tells the model so, and
   the model refuses to claim SAR-based findings.
2. **Fusion is prompt-level, not a trained adapter.** The design doc's dual-encoder fusion
   adapter with LoRA is not what runs here. Do not claim a trained SAR-optical model.
3. **The demo dates are archived, not live.** Majuli 2024-10-19 vs 2024-11-28 is
   post-monsoon water retreat — a real, measurable change, but not a live flood feed.
   The UI and model always name the event date.
4. **Cluster centroids are unvalidated.** Coordinates are computed from the tile transform
   and are geometrically correct, but have not been checked against surveyed ground truth.
5. **Free-tier rate limit.** Groq allows 8,000 tokens/min and image calls are heavy; one
   429 retry is built in. Do not fire two queries within a minute during a demo.
