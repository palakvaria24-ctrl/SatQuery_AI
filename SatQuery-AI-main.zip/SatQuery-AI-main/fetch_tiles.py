"""Build one AOI end to end: download imagery, register it, derive water extent.

  python fetch_tiles.py --aoi Majuli --bbox 93.90 26.90 94.30 27.10 \
                        --event 2024-10-19 --baseline 2024-11-28

Optical true-colour : NASA GIBS HLS_S30 (Sentinel-2 harmonised, 30 m) - what the VLM looks at.
Water extent        : NASA OPERA DSWx-HLS (30 m)                      - what the map overlay is.
SAR                 : placeholder until Bhoonidhi credentials land (see bhoonidhi.py).

Everything lands in data/satquery.db (SQLite).
"""
import argparse, datetime, io, pathlib
import httpx
import numpy as np
from PIL import Image, ImageDraw
import db, detect

ROOT = pathlib.Path(__file__).parent
TILES = ROOT / "data" / "tiles"
GIBS = detect.GIBS
LAYERS = {"hls": "HLS_S30_Nadir_BRDF_Adjusted_Reflectance",        # 30 m, swath gaps
          "viirs": "VIIRS_NOAA20_CorrectedReflectance_TrueColor"}  # 375 m, daily
SIZE = 1024


def get_map(bbox, date, layer):
    lon0, lat0, lon1, lat1 = bbox
    r = httpx.get(GIBS, params={
        "SERVICE": "WMS", "REQUEST": "GetMap", "VERSION": "1.3.0",
        "LAYERS": layer, "CRS": "EPSG:4326",          # WMS 1.3.0 EPSG:4326 is lat,lon order
        "BBOX": f"{lat0},{lon0},{lat1},{lon1}", "WIDTH": SIZE, "HEIGHT": SIZE,
        "FORMAT": "image/png", "TIME": date}, timeout=120)
    r.raise_for_status()
    if "png" not in r.headers.get("content-type", ""):
        raise RuntimeError(f"GIBS refused: {r.text[:200]}")
    return r.content


def stats(png):
    """(coverage, cloud). Cloud is a bright+flat proxy, not a real mask - it only tells
    the model how much of the optical view is usable."""
    a = np.asarray(Image.open(io.BytesIO(png)).convert("RGB"), float)
    covered = a.sum(axis=2) > 12
    if not covered.any():
        return 0.0, None
    bright, flat = a.mean(axis=2) > 200, (a.max(axis=2) - a.min(axis=2)) < 25
    return round(float(covered.mean()), 2), round(float((bright & flat)[covered].mean()), 2)


def fetch_optical(bbox, date, layer, out, search_days=6, min_cover=0.5):
    """Search outward from `date` for an acquisition that actually covers the AOI."""
    d0 = datetime.date.fromisoformat(date)
    best = None
    for off in [0] + [o for n in range(1, search_days + 1) for o in (-n, n)]:
        d = (d0 + datetime.timedelta(days=off)).isoformat()
        png = get_map(bbox, d, layer)
        cover, cloud = stats(png)
        if cover >= min_cover:
            out.write_bytes(png)
            return d, cover, cloud
        if cover > 0 and (best is None or cover > best[1]):
            best = (png, cover, cloud, d)
    if best:
        out.write_bytes(best[0])
        return best[3], best[1], best[2]
    raise SystemExit(f"No {layer} coverage within +/-{search_days}d of {date}.")


def placeholder_sar(out, aoi, date):
    img = Image.new("L", (SIZE, SIZE), 40)
    d = ImageDraw.Draw(img)
    d.text((16, 16), "PLACEHOLDER SAR - NOT REAL IMAGERY", fill=230)
    d.text((16, 40), f"{aoi} {date}", fill=200)
    d.text((16, 72), "supply Bhoonidhi credentials to replace", fill=160)
    img.convert("RGB").save(out)


def register(aoi, bbox, date, layer, role):
    TILES.mkdir(parents=True, exist_ok=True)
    tid = f"{aoi.lower().replace(' ', '_')}_{date}"
    opt, sar = TILES / f"{tid}_optical.png", TILES / f"{tid}_sar.png"
    actual, cover, cloud = fetch_optical(bbox, date, LAYERS[layer], opt)
    placeholder_sar(sar, aoi, actual)
    db.upsert_tile({"id": tid, "aoi": aoi, "date": date,
                    "lon0": bbox[0], "lat0": bbox[1], "lon1": bbox[2], "lat1": bbox[3],
                    "cloud": cloud, "coverage": cover, "source": LAYERS[layer],
                    "sensor": "Sentinel-2 (HLS) via NASA GIBS",
                    "optical_path": f"data/tiles/{opt.name}", "sar_path": f"data/tiles/{sar.name}",
                    "note": f"{role}; optical acquired {actual}; SAR placeholder"})
    print(f"  {tid:28} optical={actual} coverage={cover:.0%} cloud={cloud:.0%}")
    return tid


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--aoi", required=True)
    p.add_argument("--bbox", nargs=4, type=float, required=True, metavar=("LON0", "LAT0", "LON1", "LAT1"))
    p.add_argument("--event", required=True, help="date of the situation being asked about")
    p.add_argument("--baseline", required=True, help="normal-conditions date to compare against")
    p.add_argument("--layer", choices=LAYERS, default="hls")
    p.add_argument("--cells", type=int, default=64)
    a = p.parse_args()

    print(f"{a.aoi}: registering tiles")
    register(a.aoi, a.bbox, a.baseline, a.layer, "baseline")
    register(a.aoi, a.bbox, a.event, a.layer, "event")
    print(f"{a.aoi}: deriving water extent (OPERA DSWx-HLS)")
    detect.run(a.aoi, a.bbox, a.event, a.baseline, a.cells)


if __name__ == "__main__":
    main()
