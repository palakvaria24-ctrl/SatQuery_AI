"""Offline checks - no network, no API keys. Run: python test_satquery.py

Covers the logic that would silently produce wrong numbers if it broke:
geo maths, cloud handling, clustering, DB round-trip and retrieval.
"""
import pathlib, tempfile
import numpy as np
import db, detect, tools

BBOX = (93.0, 26.0, 94.0, 27.0)


def rgba(color, n=64):
    a = np.zeros((n, n, 4), np.uint8)
    a[:, :] = [*color, 255]
    return a


def test_water_mask_excludes_cloud():
    a = rgba((255, 255, 255))
    a[0:16] = [0, 0, 255, 255]        # open water
    a[16:32] = [180, 213, 244, 255]   # partial water
    a[32:48] = [175, 175, 175, 255]   # cloud -> not valid, not water
    water, valid = detect.water_mask(a)
    assert water[0:32].all() and not water[32:].any()
    assert valid[0:32].all() and not valid[32:48].any() and valid[48:].all()


def test_cloud_is_never_counted_as_dry():
    """The failure that would fake a flood: cloud on the baseline must not read as dry land."""
    event, base = rgba((0, 0, 255)), rgba((175, 175, 175))   # wet now, cloudy at baseline
    cells, observed, total = detect.gridify(BBOX, event, base, cells_across=4)
    assert observed == 0 and cells == [], (observed, cells)


def test_gridify_classifies_change():
    event, base = rgba((255, 255, 255)), rgba((255, 255, 255))
    event[0:32] = [0, 0, 255, 255]     # top half wet on event
    base[0:16] = [0, 0, 255, 255]      # top quarter wet at baseline
    cells, observed, total = detect.gridify(BBOX, event, base, cells_across=4)
    kinds = {}
    for k, *_rest in cells:
        kinds[k] = kinds.get(k, 0) + 1
    assert observed == total == 16
    assert kinds == {"permanent_water": 4, "new_water": 4}, kinds


def test_cell_area_matches_geodesy():
    # 0.25 deg cell at ~26.5N: 27.6 km x 24.9 km ~= 68,800 ha
    assert abs(detect.cell_hectares(BBOX, 4, 4) - 68_800) < 2_000


def test_cell_georeferencing_is_north_up():
    """Image row 0 is the NORTH edge - flipping this silently moves every finding."""
    event, base = rgba((255, 255, 255)), rgba((255, 255, 255))
    event[0:16] = [0, 0, 255, 255]     # top row of pixels = north
    cells, _, _ = detect.gridify(BBOX, event, base, cells_across=4)
    news = [c for c in cells if c[0] == "new_water"]
    assert news and all(abs(c[4] - 27.0) < 1e-9 for c in news), news   # lat1 == north edge


def test_clusters_group_adjacent_cells():
    cells = [{"kind": "new_water", "lon0": 93.0 + i * 0.1, "lon1": 93.1 + i * 0.1,
              "lat0": 26.0, "lat1": 26.1, "hectares": 10.0} for i in range(3)]
    cells.append({"kind": "new_water", "lon0": 93.8, "lon1": 93.9,     # detached
                  "lat0": 26.0, "lat1": 26.1, "hectares": 5.0})
    cells.append({"kind": "permanent_water", "lon0": 93.0, "lon1": 93.1,
                  "lat0": 26.5, "lat1": 26.6, "hectares": 99.0})       # other class
    got = detect.clusters(cells, "new_water")
    assert [g["cells"] for g in got] == [3, 1], got
    assert got[0]["hectares"] == 30.0


def test_db_roundtrip_and_retrieval(tmpdb):
    db.upsert_tile({"id": "t1", "aoi": "Testpur", "date": "2024-10-19",
                    "lon0": 93.0, "lat0": 26.0, "lon1": 94.0, "lat1": 27.0,
                    "cloud": 0.1, "coverage": 1.0, "source": "x", "sensor": "y",
                    "optical_path": "", "sar_path": "", "note": "placeholder"})
    db.upsert_tile({"id": "t0", "aoi": "Testpur", "date": "2024-11-28",
                    "lon0": 93.0, "lat0": 26.0, "lon1": 94.0, "lat1": 27.0,
                    "cloud": 0.0, "coverage": 1.0, "source": "x", "sensor": "y",
                    "optical_path": "", "sar_path": "", "note": "baseline"})
    db.replace_detections("t1", "t0", [("new_water", 93.0, 26.0, 93.1, 26.1, 100.0),
                                       ("new_water", 93.1, 26.0, 93.2, 26.1, 100.0),
                                       ("permanent_water", 93.5, 26.5, 93.6, 26.6, 50.0)])
    db.set_observed("t1", 12, 16)
    s = db.summary("t1")
    assert s["new_water"] == {"cells": 2, "hectares": 200.0}, s
    assert s["permanent_water"]["hectares"] == 50.0

    db.replace_detections("t1", "t0", [("new_water", 93.0, 26.0, 93.1, 26.1, 7.0)])
    assert db.summary("t1")["new_water"]["cells"] == 1, "replace must not append"

    import server
    hits, pt = server.retrieve("is Testpur flooded?", None)
    assert [h["id"] for h in hits] == ["t1"] and pt is None      # name match, no network
    assert server.retrieve("what about Chennai?", None)[0] == []

    body = server.report("t1")
    assert "Testpur" in body and "OPERA DSWx-HLS" in body and "LIMITATIONS" in body
    assert "Bhoonidhi" in body


def _scene(color, n=96):
    a = np.zeros((n, n, 3), np.uint8)
    a[:, :] = color
    return a


def test_landcover_classes_sum_to_100():
    out = tools.landcover(_scene((60, 130, 60)))
    pct = out["metrics"]["class_percent"]
    assert abs(sum(pct.values()) - 100) < 0.5, pct
    assert out["metrics"]["dominant"] == "vegetation", pct


def test_change_detection_finds_a_known_patch():
    """A 32x32 patch inside 96x96 is 11.1% of the scene - the detector must land near it."""
    a = _scene((60, 130, 60))
    b = a.copy()
    b[32:64, 32:64] = (215, 210, 205)
    out = tools.change_detection(a, b)
    assert 8 < out["metrics"]["changed_percent"] < 14, out["metrics"]
    assert out["metrics"]["regions"] == 1, out["metrics"]
    assert 0 <= out["confidence"] <= 1


def test_change_detection_reports_nothing_on_identical_input():
    a = _scene((90, 120, 80))
    out = tools.change_detection(a, a.copy())
    assert out["metrics"]["changed_percent"] == 0.0, out["metrics"]


def test_sar_modality_is_detected():
    grey = np.stack([np.full((64, 64), 90, np.float32)] * 3)
    assert tools._looks_like_sar(grey)
    colour = np.stack([np.full((64, 64), v, np.float32) for v in (40, 120, 60)])
    assert not tools._looks_like_sar(colour)


def test_pair_compatibility_rejects_disjoint_bounds():
    a = {"preview_size": [64, 64], "georeferenced": True, "crs": "EPSG:4326",
         "bounds": [93.0, 26.0, 94.0, 27.0]}
    b = dict(a, bounds=[10.0, 10.0, 11.0, 11.0])
    assert not tools.check_pair(a, b)["ok"]
    assert tools.check_pair(a, dict(a))["ok"]


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    with tempfile.TemporaryDirectory() as d:
        orig = db.DB
        db.DB = pathlib.Path(d) / "t.db"
        try:
            for t in tests:
                t(None) if t.__code__.co_argcount else t()
                print(f"  ok  {t.__name__}")
        finally:
            db.DB = orig
    print(f"\n{len(tests)} passed")
