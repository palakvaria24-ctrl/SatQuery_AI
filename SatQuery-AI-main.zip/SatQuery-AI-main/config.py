"""Load .env into the environment.

Exists because setting environment variables differs per shell (`export` in bash,
`$env:X=` in PowerShell, `set X=` in cmd) and a variable set in one terminal does not
reach a server started in another. A .env file next to the code always works.

Real environment variables win, so CI and `export` still override the file.
"""
import os, pathlib

ENV_FILE = pathlib.Path(__file__).parent / ".env"

# Optional baked-in fallbacks. Leave EMPTY in anything that gets committed - a key here
# is a key in the repository. `python run.py` asks for a key and writes it to .env,
# which is gitignored, so the app still runs with no setup.
DEFAULTS = {
    "GROQ_API_KEY": "",
}


def load_env(path=ENV_FILE):
    """Minimal KEY=VALUE parser - no dependency needed. Returns loaded key names."""
    if not path.exists():
        return []
    loaded = []
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, val = line.partition("=")
        key, val = key.strip(), val.strip().strip('"').strip("'")
        if key and val and not os.environ.get(key):
            os.environ[key] = val
            loaded.append(key)
    return loaded


def require(name):
    """Fetch a required variable, or explain precisely how to set it."""
    val = os.environ.get(name) or DEFAULTS.get(name)
    if val:
        return val
    where = f"a .env file at {ENV_FILE}" if not ENV_FILE.exists() else str(ENV_FILE)
    raise RuntimeError(
        f"{name} is not set.\n"
        f"  Checked: process environment, and {where}\n"
        f"  Fix (pick one):\n"
        f"    PowerShell : $env:{name}=\"your_key\"\n"
        f"    cmd.exe    : set {name}=your_key\n"
        f"    bash/mac   : export {name}=your_key\n"
        f"    any shell  : add a line  {name}=your_key  to .env in the project folder\n"
        f"  Set it in the SAME terminal that starts the server, before starting it."
    )


load_env()


if __name__ == "__main__":
    # Running this file directly does nothing useful - it is the env loader, not the app.
    key = os.environ.get("GROQ_API_KEY") or DEFAULTS.get("GROQ_API_KEY") or ""
    print("config.py is a helper module, not the entry point.\n")
    print(f"  .env file      : {'found' if ENV_FILE.exists() else 'not present'}  ({ENV_FILE})")
    print(f"  GROQ_API_KEY   : {(key[:6] + '...' + key[-4:]) if len(key) > 12 else 'NOT SET'}")
    print("\nTo start SatQuery AI:\n\n    python run.py\n")
    print("run.py checks Python, dependencies, the key and the tests, then serves the app.")
